export type NavigationTab = 'admin' | 'cotizador' | 'citas' | 'promos' | 'clientes';

export interface HairLength {
  id: string;
  name: string;
  sublabel: string;
  description: string;
  multiplier: number;
  tag: string;
}

export interface SalonService {
  id: string;
  name: string;
  category: 'color' | 'cortes' | 'tratamientos' | 'paquetes';
  categoryLabel: string;
  description: string;
  basePrice: number;
  durationMinutes: number;
}

export interface SalonAddon {
  id: string;
  name: string;
  description: string;
  price: number;
  durationMinutes: number;
}

export type AppointmentStatus = 'en_proceso' | 'confirmada' | 'en_espera' | 'por_confirmar' | 'completada';

export interface Appointment {
  id: string;
  time: string;
  clientName: string;
  clientAvatar?: string;
  clientType: string;
  serviceName: string;
  serviceDetail: string;
  stylist: string;
  status: AppointmentStatus;
  total: number;
  date: string;
  durationStr: string;
}

export interface ClientProfile {
  id: string;
  name: string;
  tier: 'VIP Gold' | 'VIP Silver' | 'Frecuente' | 'Nueva' | 'Inactivo';
  category: 'vip' | 'frecuente' | 'nuevo' | 'inactivo';
  phone: string;
  avatar: string;
  points: number;
  visitsCount: number;
  lastService: string;
  lastServiceTimeAgo: string;
  technicalFormula: string;
  notes: string;
}

export interface SalonPromo {
  id: string;
  title: string;
  badge: string;
  description: string;
  price: number;
  originalPrice?: number;
  discountTag: string;
  duration: string;
  image: string;
  perks: string;
}

export interface Stylist {
  id: string;
  name: string;
  role: string;
  chair: string;
  status: 'ocupada' | 'disponible' | 'en_pausa';
  statusText: string;
  timeDetail: string;
  avatar: string;
}
