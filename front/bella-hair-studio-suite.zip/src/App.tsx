import React, { useState } from 'react';
import { NavigationTab, Appointment, ClientProfile, SalonPromo, SalonService, SalonAddon, HairLength } from './types';
import { INITIAL_APPOINTMENTS, INITIAL_CLIENTS } from './data/salonData';
import { NavigationSidebar } from './components/NavigationSidebar';
import { TopHeader } from './components/TopHeader';
import { MobileNavBar } from './components/MobileNavBar';
import { DashboardView } from './components/DashboardView';
import { CotizadorView } from './components/CotizadorView';
import { AgendaCitasView } from './components/AgendaCitasView';
import { PromocionesView } from './components/PromocionesView';
import { DirectorioClientesView } from './components/DirectorioClientesView';
import { NewAppointmentModal } from './components/NewAppointmentModal';
import { FormulaModal } from './components/FormulaModal';
import { RegisterAuditModal } from './components/RegisterAuditModal';
import { Toast } from './components/Toast';

export function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('admin');
  const [appointments, setAppointments] = useState<Appointment[]>(INITIAL_APPOINTMENTS);
  const [clients, setClients] = useState<ClientProfile[]>(INITIAL_CLIENTS);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Modals state
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState<boolean>(false);
  const [preselectedClient, setPreselectedClient] = useState<string>('');
  const [isFormulaOpen, setIsFormulaOpen] = useState<boolean>(false);
  const [formulaModalData, setFormulaModalData] = useState<{ clientName: string; formula: string }>({
    clientName: '',
    formula: '',
  });
  const [isAuditOpen, setIsAuditOpen] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Toast helper
  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage((prev) => (prev === message ? null : prev));
    }, 4000);
  };

  // Handler for adding appointment from Modal
  const handleAddAppointment = (newApt: Appointment) => {
    setAppointments((prev) => [newApt, ...prev]);
    showToast(`Cita confirmada para ${newApt.clientName} a las ${newApt.time}`);
  };

  // Handler for booking from Cotizador
  const handleBookFromQuote = (bookingData: {
    services: SalonService[];
    addons: SalonAddon[];
    hairLength: HairLength;
    total: number;
    stylist: string;
    date: string;
  }) => {
    const mainService = bookingData.services[0]?.name || 'Servicio Personalizado';
    const detail = `Melena ${bookingData.hairLength.name} • ${bookingData.services.length} servicios + ${bookingData.addons.length} add-ons`;

    const newApt: Appointment = {
      id: `apt-${Date.now()}`,
      clientName: 'Clienta Cotizador Web',
      clientType: 'Reserva Directa',
      serviceName: mainService,
      serviceDetail: detail,
      stylist: bookingData.stylist.split(' ')[0] + ' ' + (bookingData.stylist.split(' ')[1] || ''),
      status: 'confirmada',
      total: bookingData.total,
      date: bookingData.date,
      time: '12:00 PM',
      durationStr: `${bookingData.services.reduce((a, b) => a + b.durationMinutes, 0)} min`,
    };

    setAppointments((prev) => [newApt, ...prev]);
    setActiveTab('citas');
  };

  // Open formula modal
  const handleOpenFormula = (clientName: string, formulaText: string) => {
    setFormulaModalData({
      clientName,
      formula: formulaText,
    });
    setIsFormulaOpen(true);
  };

  // Save updated formula
  const handleSaveFormula = (clientName: string, formula: string) => {
    setClients((prev) =>
      prev.map((c) =>
        c.name.toLowerCase() === clientName.toLowerCase()
          ? { ...c, technicalFormula: formula, notes: formula.slice(0, 70) + '...' }
          : c
      )
    );
    showToast(`Ficha técnica actualizada para ${clientName}`);
  };

  // Apply promo to quote
  const handleApplyPromo = (promo: SalonPromo) => {
    showToast(`Promoción "${promo.title}" activada en tu cotizador`);
    setActiveTab('cotizador');
  };

  // Book for specific client
  const handleBookForClient = (clientName: string) => {
    setPreselectedClient(clientName);
    setIsNewAppointmentOpen(true);
  };

  // Search logic across the app
  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
    if (query.trim().length > 2) {
      // Auto suggest or navigate if query matches a section
      const lower = query.toLowerCase();
      if (lower.includes('corte') || lower.includes('color') || lower.includes('tinte') || lower.includes('tarifa') || lower.includes('precio')) {
        // Can focus cotizador
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#f8f9ff] text-[#0b1c30] flex flex-col font-sans">
      {/* Desktop Navigation Sidebar */}
      <NavigationSidebar
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        completedAppointmentsCount={appointments.filter((a) => a.status === 'en_proceso' || a.status === 'completada').length + 15}
        totalAppointmentsCount={21}
      />

      {/* Top Header */}
      <TopHeader
        searchQuery={searchQuery}
        onSearchChange={handleSearchChange}
        onOpenNewAppointment={() => {
          setPreselectedClient('');
          setIsNewAppointmentOpen(true);
        }}
        unreadAlertsCount={3}
        onOpenNotifications={() => showToast('Tienes 3 notificaciones: Lote de tintes en camino, 2 turnos por confirmar')}
      />

      {/* Main Content Area */}
      <main className="flex-1 lg:pl-72 pt-20 pb-24 lg:pb-12 px-4 sm:px-8 max-w-7xl w-full mx-auto transition-all">
        <div className="py-6 sm:py-8">
          {activeTab === 'admin' && (
            <DashboardView
              appointments={appointments}
              onOpenNewAppointment={() => {
                setPreselectedClient('');
                setIsNewAppointmentOpen(true);
              }}
              onOpenFormula={handleOpenFormula}
              onOpenRegisterAudit={() => setIsAuditOpen(true)}
              onShowToast={showToast}
              onNavigateToTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'cotizador' && (
            <CotizadorView
              onBookQuote={handleBookFromQuote}
              onShowToast={showToast}
            />
          )}

          {activeTab === 'citas' && (
            <AgendaCitasView
              appointments={appointments}
              onOpenNewAppointment={() => {
                setPreselectedClient('');
                setIsNewAppointmentOpen(true);
              }}
              onOpenFormula={handleOpenFormula}
              onShowToast={showToast}
            />
          )}

          {activeTab === 'promos' && (
            <PromocionesView
              onApplyPromoToQuote={handleApplyPromo}
              onShowToast={showToast}
            />
          )}

          {activeTab === 'clientes' && (
            <DirectorioClientesView
              clients={clients}
              onOpenNewClient={() => {
                setPreselectedClient('');
                setIsNewAppointmentOpen(true);
              }}
              onOpenFormula={handleOpenFormula}
              onBookForClient={handleBookForClient}
              onShowToast={showToast}
            />
          )}
        </div>
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <MobileNavBar
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Modals & Popups */}
      <NewAppointmentModal
        isOpen={isNewAppointmentOpen}
        onClose={() => setIsNewAppointmentOpen(false)}
        onAddAppointment={handleAddAppointment}
        preselectedClient={preselectedClient}
      />

      <FormulaModal
        isOpen={isFormulaOpen}
        onClose={() => setIsFormulaOpen(false)}
        clientName={formulaModalData.clientName}
        initialFormula={formulaModalData.formula}
        onSaveFormula={handleSaveFormula}
      />

      <RegisterAuditModal
        isOpen={isAuditOpen}
        onClose={() => setIsAuditOpen(false)}
        onShowToast={showToast}
      />

      {/* Global Interactive Toast Notification */}
      <Toast message={toastMessage} onClose={() => setToastMessage(null)} />
    </div>
  );
}

export default App;
