import React, { useState, useMemo } from 'react';
import {
  Sparkles,
  ShieldCheck,
  Star,
  Ruler,
  Clock,
  Receipt,
  SlidersHorizontal,
  CalendarDays,
  Send,
  Coffee,
  Wifi,
  Dog,
  Car,
  Check,
  ChevronDown,
  ShoppingBag,
  Lock,
} from 'lucide-react';
import {
  HAIR_LENGTHS,
  SALON_SERVICES,
  SALON_ADDONS,
  LUXURY_SINK_IMAGE_URL,
  SUGGESTED_STYLIST_AVATAR,
} from '../data/salonData';
import { HairLength, SalonService, SalonAddon } from '../types';

interface CotizadorViewProps {
  onBookQuote: (bookingData: {
    services: SalonService[];
    addons: SalonAddon[];
    hairLength: HairLength;
    total: number;
    stylist: string;
    date: string;
  }) => void;
  onShowToast: (message: string, icon?: string) => void;
}

export const CotizadorView: React.FC<CotizadorViewProps> = ({ onBookQuote, onShowToast }) => {
  // State
  const [selectedLengthId, setSelectedLengthId] = useState<string>('mediano');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedServiceIds, setSelectedServiceIds] = useState<string[]>(['1', '3']);
  const [selectedAddonIds, setSelectedAddonIds] = useState<string[]>([]);
  const [preferredStylist, setPreferredStylist] = useState<string>('Valentina Ríos (Color Master)');
  const [preferredDate, setPreferredDate] = useState<string>('2025-05-18');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Hair length object
  const currentLength = useMemo(() => {
    return HAIR_LENGTHS.find((l) => l.id === selectedLengthId) || HAIR_LENGTHS[1];
  }, [selectedLengthId]);

  // Filtered services
  const filteredServices = useMemo(() => {
    if (selectedCategory === 'all') return SALON_SERVICES;
    return SALON_SERVICES.filter((s) => s.category === selectedCategory);
  }, [selectedCategory]);

  // Selected entities
  const selectedServices = useMemo(() => {
    return SALON_SERVICES.filter((s) => selectedServiceIds.includes(s.id));
  }, [selectedServiceIds]);

  const selectedAddons = useMemo(() => {
    return SALON_ADDONS.filter((a) => selectedAddonIds.includes(a.id));
  }, [selectedAddonIds]);

  // Calculations
  const { subtotal, discount, tax, grandTotal, totalMinutes } = useMemo(() => {
    let rawServicesSubtotal = 0;
    let mins = 0;

    selectedServices.forEach((service) => {
      rawServicesSubtotal += service.basePrice * currentLength.multiplier;
      mins += service.durationMinutes;
    });

    let addonsSubtotal = 0;
    selectedAddons.forEach((addon) => {
      addonsSubtotal += addon.price;
      mins += addon.durationMinutes;
    });

    const sub = rawServicesSubtotal + addonsSubtotal;
    const disc = sub * 0.1; // 10% Bella Hair Club discount
    const taxable = Math.max(0, sub - disc);
    const calculatedTax = taxable * 0.16; // 16% IVA
    const finalTotal = taxable + calculatedTax;

    return {
      subtotal: sub,
      discount: disc,
      tax: calculatedTax,
      grandTotal: finalTotal,
      totalMinutes: mins,
    };
  }, [selectedServices, selectedAddons, currentLength]);

  // Time format helper
  const formattedDuration = useMemo(() => {
    if (totalMinutes === 0) return '0 min';
    const hrs = Math.floor(totalMinutes / 60);
    const remMins = totalMinutes % 60;
    if (hrs > 0) {
      return `${hrs}h ${remMins > 0 ? `${remMins}m` : ''}`;
    }
    return `${remMins} min`;
  }, [totalMinutes]);

  // Toggles
  const handleToggleService = (id: string) => {
    setSelectedServiceIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleToggleAddon = (id: string) => {
    setSelectedAddonIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // WhatsApp generation
  const handleSendWhatsApp = () => {
    const serviceNames = selectedServices.map((s) => s.name).join(', ');
    const addonNames = selectedAddons.map((a) => a.name).join(', ');
    const text = `¡Hola Bella Hair Studio! Diseñé mi presupuesto en el cotizador en línea:\n• Melena: ${currentLength.name} (${currentLength.tag})\n• Servicios: ${serviceNames || 'Ninguno'}\n${addonNames ? `• Add-ons: ${addonNames}\n` : ''}• Duración estimada: ${formattedDuration}\n• Inversión calculada: $${grandTotal.toFixed(2)} (IVA inc.)\n\n¿Tienen disponibilidad para agendar con ${preferredStylist}?`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
    onShowToast('Abriendo WhatsApp con tu cotización...');
  };

  // Booking action
  const handleBookNow = () => {
    if (selectedServices.length === 0 && selectedAddons.length === 0) {
      onShowToast('Por favor selecciona al menos un servicio del catálogo.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      onBookQuote({
        services: selectedServices,
        addons: selectedAddons,
        hairLength: currentLength,
        total: grandTotal,
        stylist: preferredStylist,
        date: preferredDate,
      });
      onShowToast('¡Cita bloqueada exitosamente! Revisa tu agenda.');
    }, 800);
  };

  return (
    <div className="flex flex-col w-full">
      {/* Decorative ambient backdrop */}
      <div className="relative w-full overflow-hidden">
        <div className="absolute -top-16 -right-20 w-96 h-96 rounded-full bg-[#ffb0cd]/20 blur-3xl pointer-events-none"></div>
        <div className="absolute top-72 -left-20 w-80 h-80 rounded-full bg-[#d5e3fd]/30 blur-3xl pointer-events-none"></div>

        {/* Editorial Masthead Banner */}
        <div className="relative z-10 w-full mb-8 pt-2">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#b10e6b]/10 text-[#b10e6b] text-[11px] uppercase tracking-widest font-bold">
                  <Sparkles className="w-3.5 h-3.5" />
                  Tarifario 2025 • Salón & Spa
                </span>
                <span className="text-[#574048] text-xs">Actualizado hoy</span>
              </div>
              <h1 className="font-serif text-2xl sm:text-3xl lg:text-4xl text-[#0b1c30] tracking-tight font-bold">
                Cotizador Interactivo & Tarifario Oficial
              </h1>
              <p className="text-sm text-[#515f74] max-w-2xl leading-relaxed">
                Diseña tu experiencia personalizada. Selecciona el largo de tu melena para
                ajustar insumos técnicos con total transparencia y reserva al instante.
              </p>
            </div>

            {/* Salon Metric Badge */}
            <div className="flex items-center gap-3.5 bg-white p-3.5 rounded-2xl shadow-xs border border-[#eff4ff] shrink-0">
              <div className="w-12 h-12 rounded-xl bg-[#ffd9e4] flex items-center justify-center text-[#b10e6b]">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-1 text-[#0b1c30] font-bold text-base">
                  <span>4.98</span>
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                </div>
                <p className="text-xs text-[#515f74]">Garantía Bella Hair (3,420+ clientas)</p>
              </div>
            </div>
          </div>

          {/* Hair Length Factor Selector */}
          <div className="mt-8 p-6 bg-white rounded-2xl shadow-xs border border-[#eff4ff]">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
              <div className="flex items-center gap-2">
                <Ruler className="w-5 h-5 text-[#b10e6b]" />
                <span className="text-sm sm:text-base font-bold text-[#0b1c30]">
                  Paso 1: Selecciona el Largo de tu Cabello
                </span>
              </div>
              <span className="text-xs text-[#515f74]">
                Ajusta gramaje de fórmulas y tiempo de sillón
              </span>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5" id="length-selector">
              {HAIR_LENGTHS.map((item) => {
                const isSelected = selectedLengthId === item.id;
                return (
                  <button
                    key={item.id}
                    id={`length-btn-${item.id}`}
                    type="button"
                    onClick={() => setSelectedLengthId(item.id)}
                    className={`group relative p-4 rounded-xl text-left transition-all duration-200 flex flex-col justify-between h-28 focus:outline-none ${
                      isSelected
                        ? 'bg-[#ffd9e4]/40 ring-2 ring-[#b10e6b] shadow-sm'
                        : 'bg-[#eff4ff] hover:bg-[#e5eeff]'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
                          isSelected ? 'text-[#b10e6b]' : 'text-[#515f74]'
                        }`}
                      >
                        <Ruler className="w-5 h-5" />
                      </div>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                          isSelected
                            ? 'bg-[#b10e6b] text-white'
                            : 'bg-[#d3e4fe] text-[#515f74]'
                        }`}
                      >
                        {item.tag}
                      </span>
                    </div>
                    <div>
                      <p
                        className={`text-sm font-bold ${
                          isSelected ? 'text-[#b10e6b]' : 'text-[#0b1c30]'
                        }`}
                      >
                        {item.name}
                      </p>
                      <p className="text-xs text-[#515f74] truncate">{item.sublabel}</p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Main Workspace: 2 Balanced Columns */}
        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* LEFT COLUMN: Catalog & Selection (7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            {/* Category Filter Pills */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1" id="category-filters">
              {[
                { id: 'all', label: 'Todos' },
                { id: 'color', label: 'Colorimetría' },
                { id: 'cortes', label: 'Cortes & Brushing' },
                { id: 'tratamientos', label: 'Tratamientos Capilares' },
                { id: 'paquetes', label: 'Paquetes Especiales' },
              ].map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  id={`cat-pill-${cat.id}`}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-4 py-2 rounded-full text-xs font-semibold transition-all whitespace-nowrap shadow-xs ${
                    selectedCategory === cat.id
                      ? 'bg-[#b10e6b] text-white'
                      : 'bg-white text-[#515f74] hover:text-[#0b1c30] border border-[#eff4ff]'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Service Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredServices.map((service) => {
                const isSelected = selectedServiceIds.includes(service.id);
                const calculatedPrice = (service.basePrice * currentLength.multiplier).toFixed(2);

                return (
                  <div
                    key={service.id}
                    id={`service-card-${service.id}`}
                    onClick={() => handleToggleService(service.id)}
                    className={`group rounded-2xl p-5 shadow-xs transition-all duration-200 cursor-pointer relative flex flex-col justify-between border ${
                      isSelected
                        ? 'bg-white border-[#b10e6b] ring-1 ring-[#b10e6b]/30 shadow-md'
                        : 'bg-white border-[#eff4ff] hover:border-[#dce9ff] hover:shadow-sm'
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-5 h-5 rounded flex items-center justify-center transition-colors border ${
                              isSelected
                                ? 'bg-[#b10e6b] border-[#b10e6b] text-white'
                                : 'border-[#debec8] bg-white'
                            }`}
                          >
                            {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                          </div>
                          <span className="text-[10px] uppercase font-bold text-[#b10e6b] bg-[#ffd9e4]/70 px-2 py-0.5 rounded-md">
                            {service.categoryLabel}
                          </span>
                        </div>

                        <div className="flex items-center gap-1 text-[#515f74] text-xs">
                          <Clock className="w-3.5 h-3.5 text-[#8b7079]" />
                          <span>{service.durationMinutes} min</span>
                        </div>
                      </div>

                      <h3 className="font-sans text-base font-bold text-[#0b1c30] group-hover:text-[#b10e6b] transition-colors leading-snug">
                        {service.name}
                      </h3>
                      <p className="text-xs text-[#515f74] mt-1.5 leading-relaxed">
                        {service.description}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-[#f8f9ff] flex items-baseline justify-between">
                      <span className="text-xs text-[#515f74]">Inversión calculada</span>
                      <div className="text-right">
                        <span className="font-serif text-xl font-bold text-[#0b1c30]">
                          ${calculatedPrice}
                        </span>
                        <span className="text-[10px] text-[#515f74] block">IVA inc.</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Add-on Section: Mimos & Cuidados */}
            <div className="p-6 bg-white rounded-2xl shadow-xs border border-[#eff4ff]">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-4">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#b10e6b]" />
                  <h3 className="text-base font-bold text-[#0b1c30]">
                    Mimos & Cuidados Especiales (Add-ons)
                  </h3>
                </div>
                <span className="text-[10px] uppercase font-bold text-[#b10e6b]">
                  Recomendado por estilistas
                </span>
              </div>

              <div className="space-y-3">
                {SALON_ADDONS.map((addon) => {
                  const isChecked = selectedAddonIds.includes(addon.id);
                  return (
                    <label
                      key={addon.id}
                      id={`addon-row-${addon.id}`}
                      className={`flex items-center justify-between p-3.5 rounded-xl cursor-pointer transition-all border ${
                        isChecked
                          ? 'bg-[#ffd9e4]/20 border-[#b10e6b]/40'
                          : 'bg-[#eff4ff] border-transparent hover:bg-[#e5eeff]'
                      }`}
                    >
                      <div className="flex items-center gap-3.5">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleAddon(addon.id)}
                          className="w-4 h-4 rounded accent-[#b10e6b] cursor-pointer"
                        />
                        <div>
                          <p className="text-xs sm:text-sm font-bold text-[#0b1c30]">
                            {addon.name}
                          </p>
                          <p className="text-xs text-[#515f74]">{addon.description}</p>
                        </div>
                      </div>
                      <span className="text-xs sm:text-sm font-bold text-[#0b1c30] shrink-0 ml-2">
                        +${addon.price.toFixed(2)}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Studio Experience Showcase Card */}
            <div className="rounded-2xl overflow-hidden shadow-xs bg-[#213145] text-white p-6 flex flex-col md:flex-row items-center gap-6">
              <div className="w-full md:w-36 h-36 shrink-0 rounded-xl overflow-hidden bg-white/10">
                <img
                  src={LUXURY_SINK_IMAGE_URL}
                  alt="Protocolo Bella Hair Studio Lavacabezas"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-[#ffafd3]" />
                  <span className="text-xs font-bold tracking-wider text-[#ffafd3] uppercase">
                    Protocolo Bella Hair Studio
                  </span>
                </div>
                <h4 className="font-serif text-lg font-bold leading-snug">
                  Diagnóstico Capilar Computarizado Incluido
                </h4>
                <p className="text-xs text-[#b9c7e0] leading-relaxed">
                  Cada servicio inicia con micro-cámara capilar sin costo para corroborar elasticidad
                  y nivel de porosidad antes de aplicar cualquier fórmula química.
                </p>
              </div>
            </div>
          </div>

          {/* RIGHT COLUMN: Sticky Real-time Quote & Express Booking (5 cols) */}
          <div className="lg:col-span-5 sticky top-24 space-y-6">
            <div className="bg-white rounded-3xl p-6 shadow-md border border-[#eff4ff] relative overflow-hidden">
              {/* Card Top Brand Accent */}
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-[#b10e6b] via-[#c0488a] to-[#d23284]"></div>

              <div className="flex items-center justify-between pb-4 border-b border-[#e5eeff]">
                <div>
                  <span className="text-[10px] uppercase tracking-widest text-[#b10e6b] font-bold">
                    Resumen de Cotización
                  </span>
                  <h2 className="font-serif text-xl font-bold text-[#0b1c30]">
                    Tu Presupuesto en Vivo
                  </h2>
                </div>
                <div className="p-2.5 rounded-xl bg-[#eff4ff] text-[#b10e6b]">
                  <Receipt className="w-6 h-6" />
                </div>
              </div>

              {/* Hair length pill indicator */}
              <div className="mt-4 p-3 rounded-xl bg-[#eff4ff] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <SlidersHorizontal className="w-4 h-4 text-[#515f74]" />
                  <span className="text-xs font-semibold text-[#0b1c30]">Factor de Melena:</span>
                </div>
                <span className="text-xs font-bold text-[#b10e6b] bg-[#ffd9e4] px-2.5 py-1 rounded-full">
                  {currentLength.name} ({currentLength.tag})
                </span>
              </div>

              {/* Selected Concepts Container */}
              <div className="my-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] uppercase font-bold text-[#515f74]">
                    Conceptos Seleccionados
                  </span>
                  <span className="text-xs font-semibold text-[#574048]">
                    {selectedServices.length + selectedAddons.length}{' '}
                    {selectedServices.length + selectedAddons.length === 1
                      ? 'concepto'
                      : 'conceptos'}
                  </span>
                </div>

                <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
                  {selectedServices.length === 0 && selectedAddons.length === 0 ? (
                    <div className="py-8 text-center text-[#515f74] flex flex-col items-center gap-2">
                      <ShoppingBag className="w-8 h-8 text-[#b9c7e0]" />
                      <p className="text-xs">
                        Selecciona uno o más servicios del catálogo para calcular tu tarifa
                        personalizada.
                      </p>
                    </div>
                  ) : (
                    <>
                      {selectedServices.map((service) => {
                        const price = service.basePrice * currentLength.multiplier;
                        return (
                          <div
                            key={service.id}
                            className="flex items-center justify-between p-2.5 rounded-xl bg-[#eff4ff] text-xs"
                          >
                            <div className="min-w-0 pr-2">
                              <span className="font-semibold text-[#0b1c30] block truncate">
                                {service.name}
                              </span>
                              <span className="text-[#515f74] text-[11px]">
                                {service.durationMinutes} min
                              </span>
                            </div>
                            <span className="font-bold text-[#0b1c30] shrink-0">
                              ${price.toFixed(2)}
                            </span>
                          </div>
                        );
                      })}

                      {selectedAddons.map((addon) => (
                        <div
                          key={addon.id}
                          className="flex items-center justify-between p-2.5 rounded-xl bg-[#eff4ff] text-xs"
                        >
                          <div className="min-w-0 pr-2">
                            <span className="font-semibold text-[#0b1c30] block truncate">
                              {addon.name}
                            </span>
                            <span className="text-[#a12e70] text-[11px]">
                              Add-on • +{addon.durationMinutes} min
                            </span>
                          </div>
                          <span className="font-bold text-[#0b1c30] shrink-0">
                            +${addon.price.toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </>
                  )}
                </div>
              </div>

              {/* Duration Estimator Bar */}
              <div className="p-3.5 rounded-xl bg-[#d5e3fd]/40 flex items-center justify-between mb-5">
                <div className="flex items-center gap-2.5">
                  <Clock className="w-5 h-5 text-[#515f74]" />
                  <span className="text-xs font-semibold text-[#0b1c30]">
                    Duración Estimada en Sillón:
                  </span>
                </div>
                <span className="text-base font-bold text-[#515f74]">{formattedDuration}</span>
              </div>

              {/* Breakdown Math */}
              <div className="space-y-2.5 py-4 border-t border-[#e5eeff] text-xs">
                <div className="flex items-center justify-between text-[#515f74]">
                  <span>Subtotal Servicios</span>
                  <span className="font-semibold text-[#0b1c30]">${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-[#b10e6b]">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />
                    Beneficio Bella Hair Club (-10%)
                  </span>
                  <span className="font-bold">-${discount.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-[#515f74]">
                  <span>IVA Estimado (16%)</span>
                  <span className="font-semibold text-[#0b1c30]">${tax.toFixed(2)}</span>
                </div>

                <div className="pt-3 border-t border-[#e5eeff] flex items-baseline justify-between">
                  <div>
                    <span className="text-sm font-bold text-[#0b1c30]">Total Inversión</span>
                    <span className="block text-[10px] text-emerald-600 font-semibold">
                      Precio garantizado en salón
                    </span>
                  </div>
                  <span className="font-serif text-3xl font-bold text-[#b10e6b] tracking-tight">
                    ${grandTotal.toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Quick Booking Options */}
              <div className="mt-4 pt-4 border-t border-[#e5eeff] space-y-4">
                <span className="text-[10px] uppercase font-bold text-[#515f74] block">
                  Agenda tu Cita Inmediata
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs text-[#515f74] font-semibold">
                      Estilista Sugerido
                    </label>
                    <div className="relative">
                      <select
                        id="quote-stylist-select"
                        value={preferredStylist}
                        onChange={(e) => setPreferredStylist(e.target.value)}
                        className="w-full py-2.5 px-3 bg-[#eff4ff] rounded-xl text-xs text-[#0b1c30] font-medium focus:outline-none focus:ring-2 focus:ring-[#b10e6b]/20 appearance-none pr-8 cursor-pointer"
                      >
                        <option>Valentina Ríos (Color Master)</option>
                        <option>Camila Torres (Keratinas & Corte)</option>
                        <option>Mateo Silva (Balayage Artist)</option>
                        <option>Sofía Méndez (Color Touch)</option>
                      </select>
                      <ChevronDown className="w-4 h-4 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none text-[#515f74]" />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-[#515f74] font-semibold">Fecha Deseada</label>
                    <div className="relative">
                      <input
                        id="quote-date-input"
                        type="date"
                        value={preferredDate}
                        onChange={(e) => setPreferredDate(e.target.value)}
                        className="w-full py-2.5 px-3 bg-[#eff4ff] rounded-xl text-xs text-[#0b1c30] font-medium focus:outline-none focus:ring-2 focus:ring-[#b10e6b]/20 cursor-pointer"
                      />
                    </div>
                  </div>
                </div>

                {/* Stylist preview snippet */}
                <div className="p-2.5 rounded-xl bg-[#eff4ff] flex items-center gap-3 border border-[#dce9ff]">
                  <img
                    src={SUGGESTED_STYLIST_AVATAR}
                    alt="Estilista Valentina"
                    className="w-9 h-9 rounded-full object-cover ring-1 ring-[#b10e6b]/30"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-[#0b1c30] truncate">
                      {preferredStylist}
                    </p>
                    <p className="text-[10px] text-[#515f74] truncate">
                      Disponibilidad más cercana: Hoy 4:30 PM
                    </p>
                  </div>
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0"></span>
                </div>

                {/* Action CTAs */}
                <div className="space-y-2.5 pt-2">
                  <button
                    id="btn-book-quote"
                    type="button"
                    disabled={isSubmitting}
                    onClick={handleBookNow}
                    className="w-full py-3.5 px-6 rounded-full bg-[#b10e6b] hover:bg-[#930b58] text-white text-sm font-bold shadow-md shadow-[#b10e6b]/20 transition-all transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    <CalendarDays className="w-4 h-4" />
                    <span>
                      {isSubmitting ? 'Generando Reserva...' : 'Agendar con este Presupuesto'}
                    </span>
                  </button>

                  <button
                    id="btn-whatsapp-quote"
                    type="button"
                    onClick={handleSendWhatsApp}
                    className="w-full py-3.5 px-6 rounded-full bg-[#515f74] hover:bg-[#213145] text-white text-sm font-bold transition-all transform active:scale-95 flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Enviar Presupuesto por WhatsApp</span>
                  </button>
                </div>
              </div>

              {/* Trust & Cancellation Footnote */}
              <div className="mt-4 pt-3 flex items-center justify-center gap-2 text-center text-[#515f74] text-[11px]">
                <Lock className="w-3.5 h-3.5 text-[#b10e6b]" />
                <span>Sin cargos ocultos • Cancelación flexible hasta 12h antes</span>
              </div>
            </div>

            {/* Studio Perks Mini Bento Card */}
            <div className="p-5 rounded-2xl bg-[#eff4ff] border border-[#dce9ff] space-y-3">
              <span className="text-[10px] uppercase font-bold text-[#515f74]">
                Cortesías en tu Visita
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs text-[#0b1c30]">
                <div className="flex items-center gap-2 p-2 rounded-xl bg-white border border-[#eff4ff]">
                  <Coffee className="w-4 h-4 text-[#b10e6b]" />
                  <span>Barra de Café & Mimosa</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded-xl bg-white border border-[#eff4ff]">
                  <Wifi className="w-4 h-4 text-[#b10e6b]" />
                  <span>WiFi de Alta Velocidad</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded-xl bg-white border border-[#eff4ff]">
                  <Dog className="w-4 h-4 text-[#b10e6b]" />
                  <span>Pet Friendly Friendly</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded-xl bg-white border border-[#eff4ff]">
                  <Car className="w-4 h-4 text-[#b10e6b]" />
                  <span>Valet Parking Gratuito</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
