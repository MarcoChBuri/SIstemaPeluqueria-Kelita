import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Phone,
  MessageCircle,
  Award,
  Calendar,
  Sparkles,
  ClipboardList,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { ClientProfile } from '../types';

interface DirectorioClientesViewProps {
  clients: ClientProfile[];
  onOpenNewClient: () => void;
  onOpenFormula: (clientName: string, formulaText: string) => void;
  onBookForClient: (clientName: string) => void;
  onShowToast: (message: string, icon?: string) => void;
}

export const DirectorioClientesView: React.FC<DirectorioClientesViewProps> = ({
  clients,
  onOpenNewClient,
  onOpenFormula,
  onBookForClient,
  onShowToast,
}) => {
  const [filterCategory, setFilterCategory] = useState<'all' | 'vip' | 'frecuente' | 'nuevo'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredClients = clients.filter((client) => {
    if (filterCategory !== 'all' && client.category !== filterCategory) return false;
    if (searchQuery.trim() === '') return true;
    const q = searchQuery.toLowerCase();
    return (
      client.name.toLowerCase().includes(q) ||
      client.phone.includes(q) ||
      client.lastService.toLowerCase().includes(q) ||
      client.tier.toLowerCase().includes(q)
    );
  });

  const handleWhatsAppChat = (client: ClientProfile) => {
    const message = `¡Hola ${client.name}! Te escribimos de Bella Hair Studio. ¿Te gustaría agendar tu próximo retoque o mantenimiento?`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
    onShowToast(`Abriendo chat con ${client.name}...`);
  };

  return (
    <div className="flex flex-col w-full gap-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ffd9e4] text-[#8c0053] text-[11px] font-bold uppercase tracking-wider">
              <Users className="w-3.5 h-3.5" />
              Gestión de Relaciones con Clientas (CRM)
            </span>
            <span className="text-xs text-[#515f74]">Base Activa</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl text-[#0b1c30] font-bold tracking-tight">
            Directorio de Clientas & Fichas Técnicas
          </h1>
          <p className="text-sm text-[#515f74] mt-1">
            Accede al historial capilar, registro de colorimetría, alergias y puntos acumulados.
          </p>
        </div>

        <button
          onClick={onOpenNewClient}
          className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#b10e6b] hover:bg-[#930b58] text-white text-xs sm:text-sm font-semibold shadow-sm transition-all active:scale-95 cursor-pointer self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Nueva Clienta</span>
        </button>
      </div>

      {/* Stats Counters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-white shadow-xs border border-[#eff4ff] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#ffd9e4] text-[#b10e6b] flex items-center justify-center font-bold">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xl font-bold font-serif text-[#0b1c30]">1,248</span>
            <p className="text-xs text-[#515f74]">Clientas Registradas</p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white shadow-xs border border-[#eff4ff] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#d5e3fd] text-[#515f74] flex items-center justify-center font-bold">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xl font-bold font-serif text-[#0b1c30]">342</span>
            <p className="text-xs text-[#515f74]">Socias VIP Club</p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-white shadow-xs border border-[#eff4ff] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#ffd8e7] text-[#a12e70] flex items-center justify-center font-bold">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xl font-bold font-serif text-[#0b1c30]">94.2%</span>
            <p className="text-xs text-[#515f74]">Tasa de Retención a 60 Días</p>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-white shadow-xs border border-[#eff4ff] flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search */}
        <div className="relative w-full md:max-w-md">
          <Search className="w-4 h-4 text-[#515f74] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por nombre, teléfono o servicio..."
            className="w-full pl-10 pr-4 py-2 bg-[#eff4ff] rounded-full text-xs text-[#0b1c30] placeholder:text-[#8b7079] focus:outline-none focus:ring-2 focus:ring-[#b10e6b]/20"
          />
        </div>

        {/* Categories */}
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
          {[
            { id: 'all', label: 'Todas' },
            { id: 'vip', label: 'VIP Club' },
            { id: 'frecuente', label: 'Frecuentes' },
            { id: 'nuevo', label: 'Nuevas' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setFilterCategory(cat.id as any)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                filterCategory === cat.id
                  ? 'bg-[#b10e6b] text-white'
                  : 'bg-[#eff4ff] text-[#515f74] hover:text-[#0b1c30]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Clients Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredClients.map((client) => (
          <div
            key={client.id}
            className="p-6 rounded-2xl bg-white shadow-xs border border-[#eff4ff] hover:border-[#dce9ff] hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              {/* Card Header with Avatar & Tier */}
              <div className="flex items-start justify-between gap-4 mb-4">
                <div className="flex items-center gap-3.5">
                  <img
                    src={client.avatar}
                    alt={client.name}
                    className="w-14 h-14 rounded-full object-cover ring-2 ring-[#ffd9e4]"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h3 className="font-sans text-base font-bold text-[#0b1c30]">{client.name}</h3>
                    <p className="text-xs text-[#515f74] flex items-center gap-1 mt-0.5">
                      <Phone className="w-3.5 h-3.5 text-[#8b7079]" />
                      {client.phone}
                    </p>
                  </div>
                </div>

                <span
                  className={`px-2.5 py-1 rounded-full text-[10px] font-bold shrink-0 ${
                    client.tier.includes('VIP')
                      ? 'bg-[#ffd9e4] text-[#8c0053]'
                      : 'bg-[#d5e3fd] text-[#0d1c2f]'
                  }`}
                >
                  {client.tier}
                </span>
              </div>

              {/* Badges & Stats */}
              <div className="grid grid-cols-2 gap-2 p-3 rounded-xl bg-[#eff4ff] mb-4 text-xs">
                <div>
                  <span className="text-[#515f74] text-[10px] block">Puntos Acumulados</span>
                  <span className="font-bold text-[#b10e6b]">{client.points} pts</span>
                </div>
                <div>
                  <span className="text-[#515f74] text-[10px] block">Visitas en Estudio</span>
                  <span className="font-bold text-[#0b1c30]">{client.visitsCount} visitas</span>
                </div>
              </div>

              {/* Last Service & Formula Notes */}
              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-[11px] font-bold text-[#0b1c30] block">
                    Último Servicio Realizado
                  </span>
                  <p className="text-[#515f74]">
                    {client.lastService} •{' '}
                    <span className="text-[#b10e6b] font-medium">
                      {client.lastServiceTimeAgo}
                    </span>
                  </p>
                </div>

                <div className="p-3 rounded-xl bg-[#f8f9ff] border border-[#e5eeff]">
                  <span className="text-[10px] uppercase font-bold text-[#515f74] block mb-1">
                    Nota Técnica de Colorimetría
                  </span>
                  <p className="text-[#574048] text-xs line-clamp-2 italic">
                    "{client.notes}"
                  </p>
                </div>
              </div>
            </div>

            {/* Actions Footer */}
            <div className="mt-5 pt-4 border-t border-[#eff4ff] flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => onOpenFormula(client.name, client.technicalFormula)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#eff4ff] hover:bg-[#d5e3fd] text-xs font-semibold text-[#0b1c30] transition-colors cursor-pointer"
              >
                <ClipboardList className="w-4 h-4 text-[#b10e6b]" />
                <span>Ficha Técnica</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleWhatsAppChat(client)}
                  className="p-2 rounded-xl bg-[#eff4ff] hover:bg-emerald-100 hover:text-emerald-700 text-[#515f74] transition-colors cursor-pointer"
                  title="Escribir por WhatsApp"
                >
                  <MessageCircle className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => onBookForClient(client.name)}
                  className="px-4 py-2 rounded-full bg-[#b10e6b] hover:bg-[#930b58] text-white text-xs font-bold transition-all active:scale-95 cursor-pointer"
                >
                  Agendar Turno
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
