import React, { useState } from 'react';
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Clock,
  Plus,
  Scissors,
  CheckCircle,
  Phone,
  MessageCircle,
  AlertCircle,
  FileText,
  User,
  Filter,
} from 'lucide-react';
import { Appointment } from '../types';

interface AgendaCitasViewProps {
  appointments: Appointment[];
  onOpenNewAppointment: () => void;
  onOpenFormula: (clientName: string, formulaText: string) => void;
  onShowToast: (message: string, icon?: string) => void;
}

export const AgendaCitasView: React.FC<AgendaCitasViewProps> = ({
  appointments,
  onOpenNewAppointment,
  onOpenFormula,
  onShowToast,
}) => {
  const [selectedDate, setSelectedDate] = useState<string>('2024-10-16');
  const [selectedStylistFilter, setSelectedStylistFilter] = useState<string>('all');

  const daysOfWeek = [
    { day: 'Lun', dateNum: '14', fullDate: '2024-10-14', count: 4 },
    { day: 'Mar', dateNum: '15', fullDate: '2024-10-15', count: 8 },
    { day: 'Mié', dateNum: '16', fullDate: '2024-10-16', count: 6, isToday: true },
    { day: 'Jue', dateNum: '17', fullDate: '2024-10-17', count: 7 },
    { day: 'Vie', dateNum: '18', fullDate: '2024-10-18', count: 9 },
    { day: 'Sáb', dateNum: '19', fullDate: '2024-10-19', count: 11, isFull: true },
  ];

  const filteredAppointments = appointments.filter((apt) => {
    if (selectedStylistFilter === 'all') return true;
    return apt.stylist.toLowerCase().includes(selectedStylistFilter.toLowerCase());
  });

  const handleStatusUpdate = (id: string, clientName: string) => {
    onShowToast(`Estado actualizado para ${clientName}: Servicio Completado.`);
  };

  return (
    <div className="flex flex-col w-full gap-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ffd9e4] text-[#8c0053] text-[11px] font-bold uppercase tracking-wider">
              <CalendarDays className="w-3.5 h-3.5" />
              Gestor de Citas & Sillones
            </span>
            <span className="text-xs text-[#515f74]">Octubre 2024</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl text-[#0b1c30] font-bold tracking-tight">
            Agenda de Citas & Tiempos en Vivo
          </h1>
          <p className="text-sm text-[#515f74] mt-1">
            Monitorea el flujo en tiempo real de cada sillón técnico, tiempos de pose y lavado.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            id="btn-agenda-new"
            onClick={onOpenNewAppointment}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#b10e6b] hover:bg-[#930b58] text-white text-xs sm:text-sm font-semibold shadow-sm transition-all active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Agendar Cita</span>
          </button>
        </div>
      </div>

      {/* Week Day Switcher & Month Controls */}
      <div className="p-4 sm:p-5 rounded-2xl bg-white shadow-xs border border-[#eff4ff] flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h2 className="font-serif text-lg font-bold text-[#0b1c30]">Octubre 2024</h2>
            <button
              onClick={() => setSelectedDate('2024-10-16')}
              className="px-2.5 py-1 rounded-full bg-[#eff4ff] hover:bg-[#d5e3fd] text-xs font-semibold text-[#0b1c30] transition-colors"
            >
              Hoy
            </button>
          </div>

          <div className="flex items-center gap-1">
            <button
              aria-label="Semana anterior"
              className="p-1.5 rounded-full hover:bg-[#eff4ff] text-[#515f74] transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              aria-label="Semana siguiente"
              className="p-1.5 rounded-full hover:bg-[#eff4ff] text-[#515f74] transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Days Pills */}
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {daysOfWeek.map((d) => {
            const isSelected = selectedDate === d.fullDate;
            return (
              <button
                key={d.fullDate}
                id={`day-pill-${d.dateNum}`}
                onClick={() => setSelectedDate(d.fullDate)}
                className={`p-3 rounded-xl flex flex-col items-center justify-center transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#b10e6b] text-white shadow-sm'
                    : 'bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1c30]'
                }`}
              >
                <span className={`text-[11px] font-semibold ${isSelected ? 'text-white/80' : 'text-[#515f74]'}`}>
                  {d.day}
                </span>
                <span className="text-lg font-bold my-0.5">{d.dateNum}</span>
                <span
                  className={`text-[10px] px-2 py-0.2 rounded-full font-bold ${
                    isSelected
                      ? 'bg-white/20 text-white'
                      : d.isFull
                      ? 'bg-rose-100 text-rose-700'
                      : 'bg-[#dce9ff] text-[#515f74]'
                  }`}
                >
                  {d.isFull ? 'Lleno' : `${d.count} citas`}
                </span>
              </button>
            );
          })}
        </div>

        {/* Stylists Filters Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pt-2 border-t border-[#f8f9ff]">
          <span className="text-xs text-[#515f74] font-semibold flex items-center gap-1 shrink-0">
            <Filter className="w-3.5 h-3.5" /> Filtrar por:
          </span>
          {[
            { id: 'all', label: 'Todos los Estilistas' },
            { id: 'camila', label: 'Camila Torres' },
            { id: 'mateo', label: 'Mateo Silva' },
            { id: 'sofia', label: 'Sofía Méndez' },
          ].map((st) => (
            <button
              key={st.id}
              onClick={() => setSelectedStylistFilter(st.id)}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedStylistFilter === st.id
                  ? 'bg-[#d23284] text-white'
                  : 'bg-[#eff4ff] text-[#515f74] hover:text-[#0b1c30]'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>
      </div>

      {/* Schedule Timeline & Free Slots */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Appointments Timeline (8 cols) */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          <div className="flex items-center justify-between px-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#515f74]">
              Línea de Tiempo • Miércoles 16 de Octubre
            </span>
            <span className="text-xs font-semibold text-[#b10e6b]">
              {filteredAppointments.length} servicios agendados
            </span>
          </div>

          <div className="space-y-3.5">
            {filteredAppointments.map((apt, index) => (
              <div
                key={apt.id}
                className="p-5 rounded-2xl bg-white shadow-xs border border-[#eff4ff] hover:border-[#dce9ff] transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-4">
                  {/* Time Badge */}
                  <div className="flex flex-col items-center justify-center w-16 h-16 rounded-xl bg-[#eff4ff] border border-[#dce9ff] shrink-0 text-center">
                    <Clock className="w-4 h-4 text-[#b10e6b] mb-0.5" />
                    <span className="text-xs font-bold text-[#0b1c30] leading-tight">
                      {apt.time.split(' ')[0]}
                    </span>
                    <span className="text-[10px] text-[#515f74] font-medium">
                      {apt.time.split(' ')[1]}
                    </span>
                  </div>

                  {/* Client and Service Info */}
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-sm sm:text-base font-bold text-[#0b1c30]">
                        {apt.clientName}
                      </h3>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#ffd9e4] text-[#8c0053]">
                        {apt.clientType}
                      </span>
                    </div>

                    <p className="text-xs font-semibold text-[#b10e6b] flex items-center gap-1.5">
                      <Scissors className="w-3.5 h-3.5" />
                      {apt.serviceName}
                    </p>

                    <p className="text-xs text-[#515f74]">{apt.serviceDetail}</p>

                    <div className="flex items-center gap-3 pt-1 text-[11px] text-[#515f74]">
                      <span>
                        Estilista: <strong className="text-[#0b1c30]">{apt.stylist}</strong>
                      </span>
                      <span>•</span>
                      <span>Duración: {apt.durationStr}</span>
                    </div>
                  </div>
                </div>

                {/* Status, Price & Quick Actions */}
                <div className="flex sm:flex-col items-end justify-between sm:justify-center gap-2 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#f8f9ff]">
                  <div className="text-right">
                    <span className="font-serif text-lg font-bold text-[#0b1c30]">
                      ${apt.total.toFixed(2)}
                    </span>
                    <span className="block text-[10px] font-bold text-emerald-600">
                      {apt.status === 'en_proceso'
                        ? 'En Atención'
                        : apt.status === 'confirmada'
                        ? 'Confirmada'
                        : 'En Espera'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        onOpenFormula(
                          apt.clientName,
                          `Ficha de ${apt.clientName}:\n- Servicio: ${apt.serviceName}\n- Detalle: ${apt.serviceDetail}\n- Estilista: ${apt.stylist}\n- Historial: Aplicado en fecha previa sin sensibilidades cutáneas.`
                        )
                      }
                      className="px-2.5 py-1.5 rounded-lg bg-[#eff4ff] hover:bg-[#d5e3fd] text-xs font-medium text-[#0b1c30] transition-colors"
                      title="Ver Ficha Técnica"
                    >
                      Ficha
                    </button>

                    <button
                      type="button"
                      onClick={() => handleStatusUpdate(apt.id, apt.clientName)}
                      className="px-3 py-1.5 rounded-lg bg-[#b10e6b] hover:bg-[#930b58] text-white text-xs font-semibold transition-all active:scale-95"
                    >
                      Completar
                    </button>
                  </div>
                </div>
              </div>
            ))}

            {/* Free Slot Available In-Between Card */}
            <div className="p-4 rounded-2xl border-2 border-dashed border-[#dce9ff] bg-[#eff4ff]/40 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white border border-[#dce9ff] flex items-center justify-center text-emerald-600 font-bold text-xs">
                  1:00 PM
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-[#0b1c30]">
                    Espacio Disponible (Sillón #02 & #04)
                  </h4>
                  <p className="text-xs text-[#515f74]">
                    Ventana libre para servicios rápidos de corte, secado o nutrición.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={onOpenNewAppointment}
                className="px-3 py-1.5 rounded-full bg-white hover:bg-[#eff4ff] text-[#b10e6b] border border-[#ffd9e4] text-xs font-bold transition-all active:scale-95"
              >
                + Bloquear
              </button>
            </div>
          </div>
        </div>

        {/* Right Sidebar: Daily Statistics & Quick Notes (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <div className="p-6 rounded-2xl bg-white shadow-xs border border-[#eff4ff] space-y-4">
            <h3 className="font-serif text-base font-bold text-[#0b1c30]">
              Resumen del Día • 16 Octubre
            </h3>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-2 border-b border-[#f8f9ff]">
                <span className="text-[#515f74]">Citas Confirmadas</span>
                <span className="font-bold text-[#0b1c30]">6 clientas</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[#f8f9ff]">
                <span className="text-[#515f74]">Facturación Estimada</span>
                <span className="font-bold text-[#b10e6b] font-serif text-sm">$545.00</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[#f8f9ff]">
                <span className="text-[#515f74]">Técnicas Químicas (Color/Alisado)</span>
                <span className="font-bold text-[#0b1c30]">4 turnos</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[#f8f9ff]">
                <span className="text-[#515f74]">Tiempo Promedio de Sillón</span>
                <span className="font-bold text-[#0b1c30]">1h 45m</span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-[#ffd9e4]/30 border border-[#ffd9e4] text-xs space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-[#8c0053]">
                <AlertCircle className="w-4 h-4" />
                <span>Protocolo de Esterilización</span>
              </div>
              <p className="text-[#574048]">
                Recuerda sanitizar herramientas térmicas y peines visagistas entre cada turno.
              </p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-white shadow-xs border border-[#eff4ff] space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#515f74]">
              Confirmaciones por WhatsApp
            </h4>
            <p className="text-xs text-[#515f74]">
              3 recordatorios automáticos enviados hoy con 98% de tasa de asistencia.
            </p>
            <button
              onClick={() => onShowToast('Recordatorios de asistencia enviados por WhatsApp')}
              className="w-full py-2.5 px-4 rounded-full bg-[#eff4ff] hover:bg-[#d5e3fd] text-[#0b1c30] text-xs font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 text-[#b10e6b]" />
              <span>Reenviar Recordatorios</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
