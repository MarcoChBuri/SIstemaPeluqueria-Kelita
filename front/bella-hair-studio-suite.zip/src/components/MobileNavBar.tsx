import React from 'react';
import { LayoutDashboard, Calculator, CalendarDays, Tag, Users } from 'lucide-react';
import { NavigationTab } from '../types';

interface MobileNavBarProps {
  activeTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
}

export const MobileNavBar: React.FC<MobileNavBarProps> = ({ activeTab, onSelectTab }) => {
  const tabs: { id: NavigationTab; label: string; icon: React.ReactNode }[] = [
    { id: 'admin', label: 'Admin', icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: 'cotizador', label: 'Cotizador', icon: <Calculator className="w-5 h-5" /> },
    { id: 'citas', label: 'Citas', icon: <CalendarDays className="w-5 h-5" /> },
    { id: 'promos', label: 'Promos', icon: <Tag className="w-5 h-5" /> },
    { id: 'clientes', label: 'Clientes', icon: <Users className="w-5 h-5" /> },
  ];

  return (
    <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-xl border-t border-[#eff4ff] shadow-[0_-4px_20px_rgba(11,28,48,0.06)] pb-safe">
      <div className="flex items-center justify-around h-16 px-1">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`mobile-tab-${tab.id}`}
              onClick={() => onSelectTab(tab.id)}
              className={`flex flex-col items-center justify-center min-w-[56px] h-12 gap-1 transition-all ${
                isActive ? 'text-[#b10e6b] font-bold' : 'text-[#515f74] hover:text-[#0b1c30]'
              }`}
            >
              <span className={`transition-transform duration-200 ${isActive ? 'scale-110' : ''}`}>
                {tab.icon}
              </span>
              <span className="text-[10px] tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
