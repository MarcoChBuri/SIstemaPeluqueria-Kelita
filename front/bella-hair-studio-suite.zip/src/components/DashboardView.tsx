import React, { useState } from 'react';
import {
  Sparkles,
  CircleDollarSign,
  TrendingUp,
  Calendar,
  Armchair,
  UserPlus,
  Clock,
  ClipboardList,
  CheckCircle2,
  AlertTriangle,
  Truck,
  Shirt,
  CreditCard,
  Banknote,
  Send,
  MoreVertical,
  ChevronRight,
  Plus,
  Receipt,
  Eye,
  Sliders,
} from 'lucide-react';
import { Appointment, Stylist } from '../types';
import { STYLISTS } from '../data/salonData';

interface DashboardViewProps {
  appointments: Appointment[];
  onOpenNewAppointment: () => void;
  onOpenFormula: (clientName: string, formulaText: string) => void;
  onOpenRegisterAudit: () => void;
  onShowToast: (message: string, icon?: string) => void;
  onNavigateToTab: (tab: any) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  appointments,
  onOpenNewAppointment,
  onOpenFormula,
  onOpenRegisterAudit,
  onShowToast,
  onNavigateToTab,
}) => {
  const [agendaFilter, setAgendaFilter] = useState<'all' | 'en_proceso' | 'por_cobrar'>('all');

  // Filtered appointments for table
  const filteredAppointments = appointments.filter((apt) => {
    if (agendaFilter === 'all') return true;
    if (agendaFilter === 'en_proceso') return apt.status === 'en_proceso';
    if (agendaFilter === 'por_cobrar') return apt.status === 'confirmada' || apt.status === 'en_espera';
    return true;
  });

  const handleChargeService = (apt: Appointment) => {
    onShowToast(`Cobro registrado para ${apt.clientName}: $${apt.total.toFixed(2)}`);
  };

  return (
    <div className="flex flex-col w-full gap-8">
      {/* Editorial Header Masthead */}
      <section className="relative overflow-hidden rounded-2xl bg-white p-6 sm:p-8 shadow-[0_4px_20px_-2px_rgba(236,72,153,0.06),0_2px_6px_-1px_rgba(51,65,85,0.04)] border border-[#eff4ff]">
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-gradient-to-br from-[#b10e6b]/10 via-[#ffd8e7]/30 to-transparent blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="flex flex-col">
            <div className="flex items-center gap-2 mb-1.5">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#d5e3fd] text-[#0d1c2f] text-[10px] font-semibold tracking-wide uppercase">
                <span className="w-2 h-2 rounded-full bg-[#b10e6b] animate-pulse"></span>
                Operaciones en Vivo
              </span>
              <span className="text-xs text-[#515f74]">Martes, 24 de Octubre de 2024</span>
            </div>

            <h1 className="font-serif text-3xl sm:text-4xl text-[#0b1c30] tracking-tight leading-none">
              ¡Hola, <span className="text-[#b10e6b] italic font-normal">Bella Studio</span>!
            </h1>
            <p className="text-sm text-[#515f74] mt-2">
              Jornada matutina activa con alta demanda de servicios químicos y peinado editorial.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 sm:gap-3">
            <button
              id="btn-open-register"
              type="button"
              onClick={onOpenRegisterAudit}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#eff4ff] hover:bg-[#d5e3fd] text-[#0b1c30] text-xs sm:text-sm font-semibold transition-all duration-200 active:scale-95 shadow-xs cursor-pointer"
            >
              <CircleDollarSign className="w-4 h-4 text-[#515f74]" />
              <span>Abrir Caja</span>
            </button>

            <button
              id="btn-report-z"
              type="button"
              onClick={() => onShowToast('Reporte Z generado y archivado en sistema')}
              className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-[#eff4ff] hover:bg-[#d5e3fd] text-[#0b1c30] text-xs sm:text-sm font-semibold transition-all duration-200 active:scale-95 shadow-xs cursor-pointer"
            >
              <Receipt className="w-4 h-4 text-[#515f74]" />
              <span>Generar Reporte Z</span>
            </button>

            <button
              id="btn-new-service-main"
              type="button"
              onClick={() => onNavigateToTab('cotizador')}
              className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#b10e6b] hover:bg-[#930b58] text-white text-xs sm:text-sm font-semibold shadow-[0_4px_14px_rgba(236,72,153,0.35)] transition-all duration-200 active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Nuevo Servicio</span>
            </button>
          </div>
        </div>
      </section>

      {/* 4 Metric Bento Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
        {/* Metric 1 */}
        <div className="relative overflow-hidden rounded-2xl bg-white p-6 shadow-xs border border-[#eff4ff] flex flex-col justify-between group hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-[#515f74]">
                Ingresos de Hoy
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="font-serif text-2xl sm:text-3xl text-[#0b1c30] font-bold">
                  $420.00
                </span>
                <span className="text-xs text-[#515f74]">/ $500.00</span>
              </div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-[#ffd9e4] flex items-center justify-center text-[#b10e6b]">
              <CircleDollarSign className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-4 flex flex-col gap-2">
            <div className="w-full bg-[#e5eeff] rounded-full h-2 overflow-hidden">
              <div
                className="bg-[#b10e6b] h-full rounded-full transition-all duration-500"
                style={{ width: '84%' }}
              ></div>
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-emerald-600 font-bold flex items-center gap-0.5">
                <TrendingUp className="w-3.5 h-3.5" /> +18.4% vs ayer
              </span>
              <span className="text-[#515f74] font-medium">84% de meta</span>
            </div>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="relative overflow-hidden rounded-2xl bg-white p-6 shadow-xs border border-[#eff4ff] flex flex-col justify-between group hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-[#515f74]">
                Citas Agendadas
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="font-serif text-2xl sm:text-3xl text-[#0b1c30] font-bold">
                  8 Citas
                </span>
              </div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-[#d5e3fd] flex items-center justify-center text-[#515f74]">
              <Calendar className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <div className="flex-1 py-1.5 px-3 rounded-lg bg-[#eff4ff] flex items-center justify-between">
              <span className="text-xs text-[#515f74]">En proceso</span>
              <span className="text-xs font-bold text-[#b10e6b]">3</span>
            </div>
            <div className="flex-1 py-1.5 px-3 rounded-lg bg-[#eff4ff] flex items-center justify-between">
              <span className="text-xs text-[#515f74]">Pendientes</span>
              <span className="text-xs font-bold text-[#0b1c30]">5</span>
            </div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="relative overflow-hidden rounded-2xl bg-white p-6 shadow-xs border border-[#eff4ff] flex flex-col justify-between group hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-[#515f74]">
                Ocupación Sillones
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="font-serif text-2xl sm:text-3xl text-[#0b1c30] font-bold">
                  6 <span className="text-[#515f74] text-lg font-normal">/ 7</span>
                </span>
                <span className="text-xs text-[#b10e6b] font-semibold">85% Capacidad</span>
              </div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-[#ffd8e7] flex items-center justify-center text-[#a12e70]">
              <Armchair className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-4 flex items-center gap-1.5">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div
                key={i}
                className="h-2.5 flex-1 rounded-full bg-[#b10e6b]"
                title={`Sillón #${i}: Ocupado`}
              ></div>
            ))}
            <div
              className="h-2.5 flex-1 rounded-full bg-[#dce9ff]"
              title="Sillón #7: Libre"
            ></div>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="relative overflow-hidden rounded-2xl bg-white p-6 shadow-xs border border-[#eff4ff] flex flex-col justify-between group hover:shadow-md transition-shadow">
          <div className="flex items-start justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-[#515f74]">
                Nuevas Clientas
              </span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="font-serif text-2xl sm:text-3xl text-[#0b1c30] font-bold">
                  +3
                </span>
                <span className="text-xs text-[#515f74]">registros hoy</span>
              </div>
            </div>
            <div className="w-10 h-10 rounded-xl bg-[#ffd9e4] flex items-center justify-center text-[#b10e6b]">
              <UserPlus className="w-5 h-5" />
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between">
            <div className="flex -space-x-2 overflow-hidden">
              <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#b10e6b] text-white text-[10px] font-bold shadow-xs ring-2 ring-white">
                VG
              </div>
              <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#515f74] text-white text-[10px] font-bold shadow-xs ring-2 ring-white">
                LR
              </div>
              <div className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#a12e70] text-white text-[10px] font-bold shadow-xs ring-2 ring-white">
                MC
              </div>
            </div>
            <span className="text-xs font-semibold text-[#b10e6b]">+150 pts fidelidad</span>
          </div>
        </div>
      </section>

      {/* Main Workspace Split Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
        {/* Left Column (8 cols): Performance Chart & Master Schedule Table */}
        <div className="xl:col-span-8 flex flex-col gap-8">
          {/* Weekly Performance Bar Chart */}
          <div className="rounded-2xl bg-white p-6 shadow-xs border border-[#eff4ff]">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-bold text-[#0b1c30]">
                    Rendimiento Semanal
                  </h2>
                  <span className="px-2 py-0.5 rounded-full bg-[#e5eeff] text-[#515f74] text-xs font-semibold">
                    Semana 43
                  </span>
                </div>
                <p className="text-xs text-[#515f74] mt-0.5">
                  Comparativa de facturación e ingresos brutos diarios
                </p>
              </div>

              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-[#b10e6b]"></span>
                  <span className="text-xs text-[#515f74]">Semana Actual</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-[#515f74]"></span>
                  <span className="text-xs text-[#515f74]">Semana Pasada</span>
                </div>
                <div className="pl-3 border-l border-[#e5eeff]">
                  <span className="font-serif text-xl sm:text-2xl text-[#0b1c30] font-bold">
                    $3,840
                  </span>
                </div>
              </div>
            </div>

            {/* SVG Chart */}
            <div className="w-full">
              <svg
                className="w-full h-56 text-[#515f74] overflow-visible"
                preserveAspectRatio="none"
                viewBox="0 0 740 220"
              >
                <line
                  stroke="currentColor"
                  strokeDasharray="4 4"
                  strokeOpacity="0.08"
                  x1="30"
                  x2="720"
                  y1="30"
                  y2="30"
                />
                <line
                  stroke="currentColor"
                  strokeDasharray="4 4"
                  strokeOpacity="0.08"
                  x1="30"
                  x2="720"
                  y1="80"
                  y2="80"
                />
                <line
                  stroke="currentColor"
                  strokeDasharray="4 4"
                  strokeOpacity="0.08"
                  x1="30"
                  x2="720"
                  y1="130"
                  y2="130"
                />
                <line
                  stroke="currentColor"
                  strokeOpacity="0.15"
                  x1="30"
                  x2="720"
                  y1="180"
                  y2="180"
                />

                <text fill="currentColor" fontSize="10" opacity="0.6" textAnchor="end" x="20" y="34">
                  $800
                </text>
                <text fill="currentColor" fontSize="10" opacity="0.6" textAnchor="end" x="20" y="84">
                  $600
                </text>
                <text fill="currentColor" fontSize="10" opacity="0.6" textAnchor="end" x="20" y="134">
                  $300
                </text>
                <text fill="currentColor" fontSize="10" opacity="0.6" textAnchor="end" x="20" y="184">
                  $0
                </text>

                {/* Bars per day */}
                <g transform="translate(60, 0)">
                  <rect fill="#515f74" height="80" opacity="0.75" rx="4" width="16" x="0" y="100" />
                  <rect fill="#b10e6b" height="110" rx="4" width="16" x="20" y="70" />
                  <text fill="currentColor" fontSize="11" fontWeight="600" textAnchor="middle" x="18" y="202">
                    Lun
                  </text>
                </g>

                <g transform="translate(155, 0)">
                  <rect fill="#515f74" height="95" opacity="0.75" rx="4" width="16" x="0" y="85" />
                  <rect fill="#b10e6b" height="125" rx="4" width="16" x="20" y="55" />
                  <text fill="#b10e6b" fontSize="11" fontWeight="700" textAnchor="middle" x="18" y="202">
                    Mar (Hoy)
                  </text>
                </g>

                <g transform="translate(250, 0)">
                  <rect fill="#515f74" height="70" opacity="0.75" rx="4" width="16" x="0" y="110" />
                  <rect
                    fill="#b10e6b"
                    height="90"
                    opacity="0.35"
                    rx="4"
                    stroke="#b10e6b"
                    strokeDasharray="2 2"
                    width="16"
                    x="20"
                    y="90"
                  />
                  <text fill="currentColor" fontSize="11" fontWeight="600" textAnchor="middle" x="18" y="202">
                    Mié
                  </text>
                </g>

                <g transform="translate(345, 0)">
                  <rect fill="#515f74" height="110" opacity="0.75" rx="4" width="16" x="0" y="70" />
                  <rect
                    fill="#b10e6b"
                    height="120"
                    opacity="0.35"
                    rx="4"
                    stroke="#b10e6b"
                    strokeDasharray="2 2"
                    width="16"
                    x="20"
                    y="60"
                  />
                  <text fill="currentColor" fontSize="11" fontWeight="600" textAnchor="middle" x="18" y="202">
                    Jue
                  </text>
                </g>

                <g transform="translate(440, 0)">
                  <rect fill="#515f74" height="130" opacity="0.75" rx="4" width="16" x="0" y="50" />
                  <rect
                    fill="#b10e6b"
                    height="140"
                    opacity="0.35"
                    rx="4"
                    stroke="#b10e6b"
                    strokeDasharray="2 2"
                    width="16"
                    x="20"
                    y="40"
                  />
                  <text fill="currentColor" fontSize="11" fontWeight="600" textAnchor="middle" x="18" y="202">
                    Vie
                  </text>
                </g>

                <g transform="translate(535, 0)">
                  <rect fill="#515f74" height="140" opacity="0.75" rx="4" width="16" x="0" y="40" />
                  <rect
                    fill="#b10e6b"
                    height="148"
                    opacity="0.35"
                    rx="4"
                    stroke="#b10e6b"
                    strokeDasharray="2 2"
                    width="16"
                    x="20"
                    y="32"
                  />
                  <text fill="currentColor" fontSize="11" fontWeight="600" textAnchor="middle" x="18" y="202">
                    Sáb
                  </text>
                </g>

                <g transform="translate(630, 0)">
                  <rect fill="#515f74" height="35" opacity="0.75" rx="4" width="16" x="0" y="145" />
                  <rect
                    fill="#b10e6b"
                    height="40"
                    opacity="0.35"
                    rx="4"
                    stroke="#b10e6b"
                    strokeDasharray="2 2"
                    width="16"
                    x="20"
                    y="140"
                  />
                  <text fill="currentColor" fontSize="11" fontWeight="600" textAnchor="middle" x="18" y="202">
                    Dom
                  </text>
                </g>
              </svg>
            </div>
          </div>

          {/* Master Schedule in Real Time */}
          <div className="rounded-2xl bg-white p-6 shadow-xs border border-[#eff4ff]">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-3">
                <h2 className="text-base sm:text-lg font-bold text-[#0b1c30]">
                  Agenda Maestra en Tiempo Real
                </h2>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setAgendaFilter('all')}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold transition-transform active:scale-95 ${
                    agendaFilter === 'all'
                      ? 'bg-[#ffd9e4] text-[#3e0022]'
                      : 'bg-[#eff4ff] text-[#515f74] hover:text-[#0b1c30]'
                  }`}
                >
                  Todas ({appointments.length})
                </button>
                <button
                  type="button"
                  onClick={() => setAgendaFilter('en_proceso')}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                    agendaFilter === 'en_proceso'
                      ? 'bg-[#ffd9e4] text-[#3e0022] font-bold'
                      : 'bg-[#eff4ff] text-[#515f74] hover:text-[#0b1c30]'
                  }`}
                >
                  En Proceso (3)
                </button>
                <button
                  type="button"
                  onClick={() => setAgendaFilter('por_cobrar')}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                    agendaFilter === 'por_cobrar'
                      ? 'bg-[#ffd9e4] text-[#3e0022] font-bold'
                      : 'bg-[#eff4ff] text-[#515f74] hover:text-[#0b1c30]'
                  }`}
                >
                  Por Cobrar (2)
                </button>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[650px]">
                <thead>
                  <tr className="bg-[#eff4ff] text-[#515f74] text-[10px] uppercase tracking-wider rounded-lg">
                    <th className="py-3 px-4 rounded-l-lg font-bold">Hora</th>
                    <th className="py-3 px-4 font-bold">Clienta</th>
                    <th className="py-3 px-4 font-bold">Servicio Principal</th>
                    <th className="py-3 px-4 font-bold">Estilista</th>
                    <th className="py-3 px-4 font-bold">Estado</th>
                    <th className="py-3 px-4 font-bold">Total</th>
                    <th className="py-3 px-4 text-right rounded-r-lg font-bold">Acción</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#eff4ff] text-xs">
                  {filteredAppointments.map((apt) => (
                    <tr
                      key={apt.id}
                      className="hover:bg-[#eff4ff]/60 transition-colors group"
                    >
                      <td className="py-4 px-4 font-bold text-[#0b1c30] whitespace-nowrap">
                        <span className="text-[#b10e6b] text-sm font-bold mr-1">
                          {apt.time.split(' ')[0]}
                        </span>
                        <span className="text-[#515f74] text-[10px]">
                          {apt.time.split(' ')[1]}
                        </span>
                      </td>

                      <td className="py-4 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-3">
                          {apt.clientAvatar ? (
                            <img
                              src={apt.clientAvatar}
                              alt={apt.clientName}
                              className="w-9 h-9 rounded-full object-cover shadow-xs ring-1 ring-[#b10e6b]/20"
                              referrerPolicy="no-referrer"
                            />
                          ) : (
                            <div className="w-9 h-9 rounded-full bg-[#ffd8e7] text-[#a12e70] flex items-center justify-center font-bold text-xs">
                              {apt.clientName
                                .split(' ')
                                .map((n) => n[0])
                                .join('')}
                            </div>
                          )}
                          <div className="flex flex-col">
                            <span className="font-bold text-[#0b1c30]">{apt.clientName}</span>
                            <span className="text-[10px] text-[#515f74]">{apt.clientType}</span>
                          </div>
                        </div>
                      </td>

                      <td className="py-4 px-4 whitespace-nowrap">
                        <div className="flex flex-col">
                          <span className="font-semibold text-[#0b1c30]">{apt.serviceName}</span>
                          <span className="text-[10px] text-[#515f74]">{apt.serviceDetail}</span>
                        </div>
                      </td>

                      <td className="py-4 px-4 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-[#b10e6b]"></span>
                          <span className="font-medium text-[#0b1c30]">{apt.stylist}</span>
                        </div>
                      </td>

                      <td className="py-4 px-4 whitespace-nowrap">
                        {apt.status === 'en_proceso' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#ffd9e4] text-[#3e0022] text-[10px] font-bold">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#b10e6b] animate-pulse"></span>
                            En Proceso
                          </span>
                        )}
                        {apt.status === 'confirmada' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#d5e3fd] text-[#0d1c2f] text-[10px] font-bold">
                            Confirmada
                          </span>
                        )}
                        {apt.status === 'en_espera' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 text-[10px] font-bold">
                            En Espera
                          </span>
                        )}
                        {apt.status === 'por_confirmar' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#ffd9e4] text-[#8c0053] text-[10px] font-bold">
                            Por Confirmar
                          </span>
                        )}
                      </td>

                      <td className="py-4 px-4 whitespace-nowrap font-serif text-sm font-bold text-[#0b1c30]">
                        ${apt.total.toFixed(2)}
                      </td>

                      <td className="py-4 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() =>
                              onOpenFormula(
                                apt.clientName,
                                `Historial de ${apt.clientName}: ${apt.serviceName}. ${apt.serviceDetail}. Recomendado mantenimiento en 4 semanas.`
                              )
                            }
                            className="p-1.5 rounded-full hover:bg-[#e5eeff] text-[#515f74] hover:text-[#b10e6b] transition-colors"
                            title="Ver Ficha Técnica"
                          >
                            <ClipboardList className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleChargeService(apt)}
                            className="px-3 py-1 rounded-full bg-[#d5e3fd] hover:bg-[#b10e6b] hover:text-white text-[#0d1c2f] text-[11px] font-bold transition-all active:scale-95"
                          >
                            Cobrar
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Stylists, Alerts, POS Cash Register */}
        <div className="xl:col-span-4 flex flex-col gap-6">
          {/* Active Stylists */}
          <div className="rounded-2xl bg-white p-6 shadow-xs border border-[#eff4ff]">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <span className="text-[#b10e6b]">
                  <Armchair className="w-5 h-5" />
                </span>
                <h2 className="text-base font-bold text-[#0b1c30]">Equipo en Salón</h2>
              </div>
              <span className="text-xs font-bold text-[#b10e6b] bg-[#ffd9e4] px-2 py-0.5 rounded-full">
                3 Activos
              </span>
            </div>

            <div className="flex flex-col gap-3.5">
              {STYLISTS.map((st) => (
                <div
                  key={st.id}
                  className="p-3.5 rounded-xl bg-[#eff4ff] flex items-center justify-between hover:bg-[#d5e3fd]/40 transition-colors border border-[#dce9ff]"
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <img
                        src={st.avatar}
                        alt={st.name}
                        className="w-11 h-11 rounded-full object-cover shadow-xs"
                        referrerPolicy="no-referrer"
                      />
                      <span
                        className={`absolute bottom-0 right-0 w-3 h-3 rounded-full ring-2 ring-white ${
                          st.status === 'ocupada'
                            ? 'bg-[#b10e6b]'
                            : st.status === 'disponible'
                            ? 'bg-emerald-500'
                            : 'bg-amber-500'
                        }`}
                      ></span>
                    </div>

                    <div className="flex flex-col">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#0b1c30]">{st.name.split(' ')[0]}</span>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold uppercase bg-[#b10e6b]/10 text-[#b10e6b]">
                          {st.chair}
                        </span>
                      </div>
                      <span className="text-[11px] text-[#515f74]">{st.statusText}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        st.status === 'ocupada'
                          ? 'bg-[#ffd9e4] text-[#b10e6b]'
                          : st.status === 'disponible'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {st.timeDetail}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Notifications & Reminders */}
          <div className="rounded-2xl bg-white p-6 shadow-xs border border-[#eff4ff]">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="text-[#b10e6b]">
                  <Sparkles className="w-5 h-5" />
                </span>
                <h2 className="text-base font-bold text-[#0b1c30]">Alertas & Recordatorios</h2>
              </div>
              <span className="w-2 h-2 rounded-full bg-[#b10e6b]"></span>
            </div>

            <div className="flex flex-col gap-3 text-xs">
              <div className="flex items-start gap-3 p-3 rounded-xl bg-[#eff4ff] border border-[#dce9ff]">
                <Truck className="w-4 h-4 text-[#b10e6b] mt-0.5 shrink-0" />
                <div className="flex flex-col">
                  <span className="font-bold text-[#0b1c30]">Reabastecimiento L'Oréal</span>
                  <p className="text-[#515f74] text-[11px]">
                    Entrega programada para las 14:00 hrs (Tintes Dia Light y reveladores).
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-[#eff4ff] border border-[#dce9ff]">
                <Shirt className="w-4 h-4 text-[#515f74] mt-0.5 shrink-0" />
                <div className="flex flex-col">
                  <span className="font-bold text-[#0b1c30]">Lavandería & Toallas</span>
                  <p className="text-[#515f74] text-[11px]">
                    Lote #2 de toallas de microfibra esterilizadas listas en vestidor.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-rose-50 border border-rose-200">
                <AlertTriangle className="w-4 h-4 text-[#ba1a1a] mt-0.5 shrink-0" />
                <div className="flex flex-col">
                  <span className="font-bold text-[#ba1a1a]">Stock Bajo: Olaplex Nº 3</span>
                  <p className="text-rose-900/80 text-[11px]">
                    Quedan solo 2 unidades para venta minorista en mostrador.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* POS Quick Cash Register */}
          <div className="rounded-2xl bg-white p-6 shadow-xs border border-[#eff4ff]">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="text-[#b10e6b]">
                  <CreditCard className="w-5 h-5" />
                </span>
                <h2 className="text-base font-bold text-[#0b1c30]">Caja Rápida POS</h2>
              </div>
              <span className="text-xs text-[#515f74] font-semibold">Corte Parcial</span>
            </div>

            <div className="grid grid-cols-3 gap-2 mb-4 text-center">
              <div className="p-2.5 rounded-xl bg-[#eff4ff] flex flex-col items-center">
                <CreditCard className="w-4 h-4 text-[#515f74] mb-1" />
                <span className="text-[10px] text-[#515f74]">Tarjeta</span>
                <span className="text-xs font-bold text-[#0b1c30] mt-0.5">$275.00</span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#eff4ff] flex flex-col items-center">
                <Banknote className="w-4 h-4 text-[#515f74] mb-1" />
                <span className="text-[10px] text-[#515f74]">Efectivo</span>
                <span className="text-xs font-bold text-[#0b1c30] mt-0.5">$105.00</span>
              </div>
              <div className="p-2.5 rounded-xl bg-[#eff4ff] flex flex-col items-center">
                <Send className="w-4 h-4 text-[#515f74] mb-1" />
                <span className="text-[10px] text-[#515f74]">Transf.</span>
                <span className="text-xs font-bold text-[#0b1c30] mt-0.5">$40.00</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-gradient-to-r from-[#b10e6b]/10 via-[#ffd8e7]/30 to-transparent flex items-center justify-between border border-[#ffd9e4]">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-[#515f74] font-bold">
                  Total Registrado
                </span>
                <div className="font-serif text-xl text-[#b10e6b] font-bold leading-tight">
                  $420.00
                </div>
              </div>
              <button
                type="button"
                onClick={onOpenRegisterAudit}
                className="px-3.5 py-2 rounded-full bg-[#0b1c30] hover:bg-[#515f74] text-white text-xs font-semibold transition-all active:scale-95 shadow-xs cursor-pointer"
              >
                Auditar Flujo
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
