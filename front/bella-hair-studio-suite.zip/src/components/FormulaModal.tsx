import React, { useState } from 'react';
import { X, Sparkles, ClipboardCheck, Save } from 'lucide-react';

interface FormulaModalProps {
  isOpen: boolean;
  onClose: () => void;
  clientName: string;
  initialFormula: string;
  onSaveFormula: (clientName: string, formula: string) => void;
}

export const FormulaModal: React.FC<FormulaModalProps> = ({
  isOpen,
  onClose,
  clientName,
  initialFormula,
  onSaveFormula,
}) => {
  const [formula, setFormula] = useState(initialFormula);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveFormula(clientName, formula);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl bg-white p-6 sm:p-8 shadow-2xl border border-[#eff4ff] relative">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-2 rounded-full hover:bg-[#eff4ff] text-[#515f74] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-1">
          <span className="p-1.5 rounded-lg bg-[#ffd9e4] text-[#b10e6b]">
            <Sparkles className="w-4 h-4" />
          </span>
          <span className="text-[10px] uppercase tracking-widest text-[#b10e6b] font-bold">
            Ficha Técnica de Salón
          </span>
        </div>

        <h2 className="font-serif text-2xl font-bold text-[#0b1c30]">
          Fórmula Química • {clientName}
        </h2>
        <p className="text-xs text-[#515f74] mt-1 mb-6">
          Registro confidencial de mezclas, gramajes, tiempos de exposición y sensibilidades cutáneas.
        </p>

        <div className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-[#0b1c30] mb-1.5">
              Especificación de Fórmula & Procedimiento
            </label>
            <textarea
              rows={6}
              value={formula}
              onChange={(e) => setFormula(e.target.value)}
              className="w-full p-4 rounded-2xl bg-[#eff4ff] text-xs text-[#0b1c30] leading-relaxed border border-[#dce9ff] focus:bg-white focus:ring-2 focus:ring-[#b10e6b]/20 outline-none"
              placeholder="Escribe la fórmula química, volúmenes de peróxido y tiempos de pose..."
            />
          </div>

          <div className="p-3.5 rounded-xl bg-[#ffd9e4]/30 border border-[#ffd9e4] flex items-center gap-3">
            <ClipboardCheck className="w-5 h-5 text-[#b10e6b] shrink-0" />
            <p className="text-[11px] text-[#574048]">
              Esta ficha se sincroniza automáticamente con el historial técnico de la clienta y el
              sistema de inventario.
            </p>
          </div>

          <div className="pt-3 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-full bg-[#eff4ff] hover:bg-[#e5eeff] text-xs font-semibold text-[#515f74]"
            >
              Cerrar
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="flex items-center gap-1.5 px-6 py-2.5 rounded-full bg-[#b10e6b] hover:bg-[#930b58] text-white text-xs font-bold shadow-sm transition-all active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>Guardar Ficha</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
