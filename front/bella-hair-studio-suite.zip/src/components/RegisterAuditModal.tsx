import React from 'react';
import { X, CircleDollarSign, CreditCard, Banknote, Send, CheckCircle2, Receipt } from 'lucide-react';

interface RegisterAuditModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast: (msg: string) => void;
}

export const RegisterAuditModal: React.FC<RegisterAuditModalProps> = ({
  isOpen,
  onClose,
  onShowToast,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-white p-6 sm:p-8 shadow-2xl border border-[#eff4ff] relative">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-2 rounded-full hover:bg-[#eff4ff] text-[#515f74] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-1">
          <span className="p-1.5 rounded-lg bg-[#ffd9e4] text-[#b10e6b]">
            <CircleDollarSign className="w-4 h-4" />
          </span>
          <span className="text-[10px] uppercase tracking-widest text-[#b10e6b] font-bold">
            Auditoría de Caja POS
          </span>
        </div>

        <h2 className="font-serif text-2xl font-bold text-[#0b1c30]">Arqueo de Turno Actual</h2>
        <p className="text-xs text-[#515f74] mt-0.5 mb-5">
          Desglose consolidado de ingresos por método de pago.
        </p>

        <div className="space-y-3 text-xs">
          <div className="p-3.5 rounded-xl bg-[#eff4ff] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <CreditCard className="w-4 h-4 text-[#515f74]" />
              <span className="font-semibold text-[#0b1c30]">Terminales de Tarjeta</span>
            </div>
            <span className="font-serif font-bold text-sm text-[#0b1c30]">$275.00</span>
          </div>

          <div className="p-3.5 rounded-xl bg-[#eff4ff] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Banknote className="w-4 h-4 text-[#515f74]" />
              <span className="font-semibold text-[#0b1c30]">Efectivo en Gaveta</span>
            </div>
            <span className="font-serif font-bold text-sm text-[#0b1c30]">$105.00</span>
          </div>

          <div className="p-3.5 rounded-xl bg-[#eff4ff] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Send className="w-4 h-4 text-[#515f74]" />
              <span className="font-semibold text-[#0b1c30]">Transferencias Bancarias</span>
            </div>
            <span className="font-serif font-bold text-sm text-[#0b1c30]">$40.00</span>
          </div>

          <div className="p-4 rounded-2xl bg-gradient-to-r from-[#ffd9e4] to-[#ffb0cd]/30 border border-[#ffd9e4] flex items-center justify-between mt-2">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#8c0053]">
                Total Cobrado en Turno
              </span>
              <div className="font-serif text-2xl font-bold text-[#b10e6b]">$420.00</div>
            </div>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full">
              Cuadrado 100%
            </span>
          </div>

          <div className="pt-4 flex items-center justify-end gap-2">
            <button
              onClick={onClose}
              className="px-5 py-2.5 rounded-full bg-[#eff4ff] hover:bg-[#e5eeff] text-xs font-semibold text-[#515f74]"
            >
              Cerrar
            </button>
            <button
              onClick={() => {
                onShowToast('Corte de caja emitido y sincronizado con contabilidad.');
                onClose();
              }}
              className="px-5 py-2.5 rounded-full bg-[#0b1c30] hover:bg-[#515f74] text-white text-xs font-bold shadow-xs transition-all active:scale-95"
            >
              Imprimir Arqueo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
