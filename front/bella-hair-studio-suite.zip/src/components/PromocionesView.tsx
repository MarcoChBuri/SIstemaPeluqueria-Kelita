import React, { useState } from 'react';
import {
  Tag,
  Sparkles,
  Copy,
  Check,
  Calendar,
  Clock,
  QrCode,
  Gift,
  ArrowRight,
  ShieldCheck,
  Percent,
} from 'lucide-react';
import { SALON_PROMOS } from '../data/salonData';
import { SalonPromo } from '../types';

interface PromocionesViewProps {
  onApplyPromoToQuote: (promo: SalonPromo) => void;
  onShowToast: (message: string, icon?: string) => void;
}

export const PromocionesView: React.FC<PromocionesViewProps> = ({
  onApplyPromoToQuote,
  onShowToast,
}) => {
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    onShowToast(`Código ${code} copiado al portapapeles`);
    setTimeout(() => setCopiedCode(null), 3000);
  };

  return (
    <div className="flex flex-col w-full gap-8">
      {/* Header Banner */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ffd9e4] text-[#8c0053] text-[11px] font-bold uppercase tracking-wider">
            <Tag className="w-3.5 h-3.5" />
            Campañas & Beneficios Exclusivos
          </span>
          <span className="text-xs text-[#515f74]">Temporada 2025</span>
        </div>
        <h1 className="font-serif text-2xl sm:text-3xl lg:text-4xl text-[#0b1c30] font-bold tracking-tight">
          Promociones y Paquetes de Salón
        </h1>
        <p className="text-sm text-[#515f74] max-w-2xl">
          Aprovecha nuestras experiencias combinadas de autor con precios preferenciales y
          cupones activos para tu próxima visita.
        </p>
      </div>

      {/* Hero Featured Campaign */}
      <div className="relative overflow-hidden rounded-3xl bg-[#213145] text-white p-6 sm:p-10 shadow-lg border border-white/10">
        <div className="absolute -right-20 -bottom-20 w-96 h-96 rounded-full bg-[#b10e6b]/30 blur-3xl pointer-events-none"></div>

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#ffd9e4] text-[#3e0022] text-xs font-bold">
              <Sparkles className="w-4 h-4 text-[#b10e6b]" />
              <span>Campaña Especial de la Semana</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight leading-tight">
              Jueves de Color: <span className="text-[#ffb0cd]">25% OFF</span> en Balayage
            </h2>

            <p className="text-sm text-[#b9c7e0] leading-relaxed max-w-xl">
              Dedica tu jueves a transformar tu cabello con nuestro equipo de Color Masters.
              Incluye diagnóstico previo, matiz orgánico y brushing pulido de cortesía.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              {/* Coupon Code Pill */}
              <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/10 backdrop-blur-md border border-white/20">
                <span className="text-xs text-[#b9c7e0]">Código:</span>
                <span className="font-mono font-bold text-base text-white tracking-wider">
                  GLAM25
                </span>
                <button
                  onClick={() => handleCopyCode('GLAM25')}
                  className="p-1.5 rounded-lg hover:bg-white/20 transition-colors text-[#ffb0cd]"
                  title="Copiar cupón"
                >
                  {copiedCode === 'GLAM25' ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>

              <button
                onClick={() =>
                  onApplyPromoToQuote({
                    id: 'hero-color',
                    title: 'Jueves de Color 25% OFF',
                    badge: '-25%',
                    description: 'Balayage & Babylights con descuento especial de jueves',
                    price: 56.25,
                    originalPrice: 75.0,
                    discountTag: '-25%',
                    duration: '2h 30m',
                    image: '',
                    perks: 'Válido los días jueves',
                  })
                }
                className="px-6 py-3 rounded-full bg-[#b10e6b] hover:bg-[#930b58] text-white text-xs sm:text-sm font-bold shadow-md transition-all active:scale-95 flex items-center gap-2 cursor-pointer"
              >
                <span>Aplicar a mi Cotización</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="lg:col-span-5 flex justify-center">
            {/* VIP Pass Mockup */}
            <div className="w-full max-w-xs p-6 rounded-2xl bg-white text-[#0b1c30] shadow-2xl border border-white/40 transform rotate-1 hover:rotate-0 transition-transform">
              <div className="flex items-center justify-between pb-3 border-b border-[#eff4ff]">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#ffd9e4] flex items-center justify-center text-[#b10e6b] font-bold text-xs">
                    BH
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-[#0b1c30]">Pase Bella VIP</h3>
                    <span className="text-[10px] text-[#515f74]">Válido en salón</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-md bg-[#b10e6b]/10 text-[#b10e6b] text-[10px] font-bold">
                  25% OFF
                </span>
              </div>

              <div className="my-4 flex flex-col items-center text-center">
                <div className="p-3 rounded-xl bg-[#f8f9ff] border border-[#e5eeff] mb-2">
                  <QrCode className="w-24 h-24 text-[#0b1c30]" />
                </div>
                <span className="font-mono text-xs font-bold text-[#515f74]">#BELLA-GLAM-25</span>
                <span className="text-[10px] text-emerald-600 font-semibold mt-1">
                  ● Activo para reservar hoy
                </span>
              </div>

              <div className="text-[10px] text-[#515f74] text-center border-t border-[#eff4ff] pt-2">
                Presenta este código al momento de tu cobro en recepción.
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Packages Cards */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#0b1c30]">
            Paquetes & Experiencias Combinadas
          </h2>
          <span className="text-xs text-[#515f74]">Precios con descuento directo</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {SALON_PROMOS.map((promo) => (
            <div
              key={promo.id}
              className="group rounded-2xl bg-white p-5 shadow-xs border border-[#eff4ff] hover:border-[#dce9ff] hover:shadow-md transition-all flex flex-col justify-between"
            >
              <div>
                <div className="relative w-full h-44 rounded-xl overflow-hidden mb-4 bg-[#eff4ff]">
                  <img
                    src={promo.image}
                    alt={promo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute top-3 left-3 px-3 py-1 rounded-full bg-[#b10e6b] text-white text-xs font-bold shadow-md">
                    {promo.badge}
                  </span>
                </div>

                <div className="flex items-center gap-2 text-[#515f74] text-xs mb-1.5">
                  <Clock className="w-3.5 h-3.5 text-[#b10e6b]" />
                  <span>{promo.duration}</span>
                  <span>•</span>
                  <span>{promo.perks}</span>
                </div>

                <h3 className="font-sans text-lg font-bold text-[#0b1c30] group-hover:text-[#b10e6b] transition-colors">
                  {promo.title}
                </h3>
                <p className="text-xs text-[#515f74] mt-2 leading-relaxed">
                  {promo.description}
                </p>
              </div>

              <div className="mt-5 pt-4 border-t border-[#f8f9ff] flex items-center justify-between">
                <div>
                  <div className="flex items-baseline gap-1.5">
                    <span className="font-serif text-2xl font-bold text-[#0b1c30]">
                      ${promo.price.toFixed(2)}
                    </span>
                    {promo.originalPrice && (
                      <span className="text-xs text-[#8b7079] line-through">
                        ${promo.originalPrice.toFixed(2)}
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-[#515f74]">IVA incluido</span>
                </div>

                <button
                  type="button"
                  onClick={() => onApplyPromoToQuote(promo)}
                  className="px-4 py-2 rounded-full bg-[#eff4ff] group-hover:bg-[#b10e6b] group-hover:text-white text-[#0b1c30] text-xs font-bold transition-all active:scale-95 cursor-pointer"
                >
                  Cotizar Pack
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Loyalty Referral & Stamp Card */}
      <div className="p-6 rounded-2xl bg-[#eff4ff] border border-[#dce9ff] flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-[#ffd9e4] flex items-center justify-center text-[#b10e6b] shrink-0">
            <Gift className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#0b1c30]">
              Programa Trae a tu Mejor Amiga
            </h3>
            <p className="text-xs text-[#515f74] max-w-md mt-0.5">
              Obtén $15.00 de crédito de salón para ambos cuando tu invitada asiste a su primer
              servicio de color o peinado.
            </p>
          </div>
        </div>

        <button
          onClick={() => onShowToast('Enlace de invitación copiado al portapapeles')}
          className="px-5 py-2.5 rounded-full bg-white hover:bg-[#e5eeff] text-[#0b1c30] border border-[#dce9ff] text-xs font-bold shadow-xs transition-all active:scale-95 shrink-0"
        >
          Compartir Mi Código de Amiga
        </button>
      </div>
    </div>
  );
};
