import React, { useState } from 'react';
import { X, Calendar, Clock, User, Scissors, DollarSign } from 'lucide-react';
import { Appointment } from '../types';

interface NewAppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddAppointment: (appointment: Appointment) => void;
  preselectedClient?: string;
}

export const NewAppointmentModal: React.FC<NewAppointmentModalProps> = ({
  isOpen,
  onClose,
  onAddAppointment,
  preselectedClient = '',
}) => {
  const [clientName, setClientName] = useState<string>(preselectedClient || '');
  const [serviceName, setServiceName] = useState<string>('Balayage Blonde & Babylights');
  const [serviceDetail, setServiceDetail] = useState<string>('Tono beige vainilla con Plex');
  const [stylist, setStylist] = useState<string>('Camila Torres');
  const [date, setDate] = useState<string>('2024-10-16');
  const [time, setTime] = useState<string>('11:00 AM');
  const [price, setPrice] = useState<number>(85);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim()) return;

    const newApt: Appointment = {
      id: `apt-${Date.now()}`,
      clientName: clientName.trim(),
      clientType: 'Cita Manual',
      serviceName,
      serviceDetail,
      stylist,
      date,
      time,
      total: price,
      status: 'confirmada',
      durationStr: '1h 30m',
    };

    onAddAppointment(newApt);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-3xl bg-white p-6 sm:p-8 shadow-2xl border border-[#eff4ff] relative">
        <button
          onClick={onClose}
          className="absolute right-5 top-5 p-2 rounded-full hover:bg-[#eff4ff] text-[#515f74] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <span className="text-[10px] uppercase tracking-widest text-[#b10e6b] font-bold">
            Recepción Bella Hair Studio
          </span>
          <h2 className="font-serif text-2xl font-bold text-[#0b1c30]">Agendar Nueva Cita</h2>
          <p className="text-xs text-[#515f74] mt-0.5">
            Bloquea un sillón de trabajo y asigna estilista especialista.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-[#0b1c30] mb-1">Nombre de la Clienta</label>
            <input
              type="text"
              required
              placeholder="Ej: Sofia Vergara"
              value={clientName}
              onChange={(e) => setClientName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#eff4ff] text-xs text-[#0b1c30] focus:bg-white focus:ring-2 focus:ring-[#b10e6b]/20 outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-[#0b1c30] mb-1">Servicio Principal</label>
              <select
                value={serviceName}
                onChange={(e) => setServiceName(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-[#eff4ff] text-xs text-[#0b1c30] focus:bg-white focus:ring-2 focus:ring-[#b10e6b]/20 outline-none cursor-pointer"
              >
                <option>Balayage Blonde & Babylights</option>
                <option>Tinte Raíz o Completo</option>
                <option>Corte & Estilo Detox</option>
                <option>Hidratación con Keratina</option>
                <option>Alisado Orgánico Espejo</option>
                <option>Peinado Novias & Gala</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-[#0b1c30] mb-1">Estilista Responsable</label>
              <select
                value={stylist}
                onChange={(e) => setStylist(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-[#eff4ff] text-xs text-[#0b1c30] focus:bg-white focus:ring-2 focus:ring-[#b10e6b]/20 outline-none cursor-pointer"
              >
                <option>Camila Torres (Sillón #01)</option>
                <option>Mateo Silva (Sillón #02)</option>
                <option>Sofía Méndez (Sillón #04)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-[#0b1c30] mb-1">Fecha</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-[#eff4ff] text-xs text-[#0b1c30] focus:bg-white focus:ring-2 focus:ring-[#b10e6b]/20 outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-[#0b1c30] mb-1">Hora</label>
              <input
                type="text"
                value={time}
                placeholder="11:00 AM"
                onChange={(e) => setTime(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-[#eff4ff] text-xs text-[#0b1c30] focus:bg-white focus:ring-2 focus:ring-[#b10e6b]/20 outline-none"
              />
            </div>

            <div>
              <label className="block font-bold text-[#0b1c30] mb-1">Inversión ($)</label>
              <input
                type="number"
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full px-3 py-2.5 rounded-xl bg-[#eff4ff] text-xs text-[#0b1c30] focus:bg-white focus:ring-2 focus:ring-[#b10e6b]/20 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-[#0b1c30] mb-1">Detalle o Notas Técnicas</label>
            <input
              type="text"
              placeholder="Ej: Prefiere matiz frío cenizo sin amoníaco"
              value={serviceDetail}
              onChange={(e) => setServiceDetail(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-[#eff4ff] text-xs text-[#0b1c30] focus:bg-white focus:ring-2 focus:ring-[#b10e6b]/20 outline-none"
            />
          </div>

          <div className="pt-4 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-full bg-[#eff4ff] hover:bg-[#e5eeff] text-xs font-semibold text-[#515f74]"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-full bg-[#b10e6b] hover:bg-[#930b58] text-white text-xs font-bold shadow-sm transition-all active:scale-95"
            >
              Confirmar Cita
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
