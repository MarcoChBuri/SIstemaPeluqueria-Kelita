import { HairLength, SalonService, SalonAddon, Appointment, ClientProfile, SalonPromo, Stylist } from '../types';

export const HAIR_LENGTHS: HairLength[] = [
  {
    id: 'corto',
    name: 'Corto',
    sublabel: 'Hasta la nuca o pixies',
    description: 'Hasta la nuca o pixies',
    multiplier: 1.0,
    tag: 'Base'
  },
  {
    id: 'mediano',
    name: 'Mediano',
    sublabel: 'Rozando hombros / clavícula',
    description: 'Hombros (+15%)',
    multiplier: 1.15,
    tag: '+15%'
  },
  {
    id: 'largo',
    name: 'Largo',
    sublabel: 'Hasta la línea del busto',
    description: 'Busto (+30%)',
    multiplier: 1.30,
    tag: '+30%'
  },
  {
    id: 'extra-largo',
    name: 'Extra Largo',
    sublabel: 'A la cintura o extensiones',
    description: 'Cintura (+45%)',
    multiplier: 1.45,
    tag: '+45%'
  }
];

export const SALON_SERVICES: SalonService[] = [
  {
    id: '1',
    name: 'Balayage Blonde & Babylights',
    category: 'color',
    categoryLabel: 'Colorimetría',
    description: 'Aclaración progresiva con efecto degradado natural, matiz orgánico y baño sellador de brillo espejo.',
    basePrice: 75,
    durationMinutes: 180
  },
  {
    id: '2',
    name: 'Tinte Raíz o Completo',
    category: 'color',
    categoryLabel: 'Colorimetría',
    description: 'Coloración sin amoníaco con cobertura 100% canas y protección lipídica que cuida la cutícula capilar.',
    basePrice: 45,
    durationMinutes: 90
  },
  {
    id: '3',
    name: 'Corte & Estilo Detox',
    category: 'cortes',
    categoryLabel: 'Cortes & Brushing',
    description: 'Diseño visagista adaptado a tu rostro, eliminación de puntas abiertas y lavado purificante con romero.',
    basePrice: 25,
    durationMinutes: 45
  },
  {
    id: '4',
    name: 'Hidratación Profunda con Keratina',
    category: 'tratamientos',
    categoryLabel: 'Tratamientos Capilares',
    description: 'Reconstrucción de la fibra capilar, reposición de ceramidas y sellado térmico anti-frizz prolongado.',
    basePrice: 35,
    durationMinutes: 60
  },
  {
    id: '5',
    name: 'Alisado Orgánico Espejo',
    category: 'tratamientos',
    categoryLabel: 'Tratamientos Capilares',
    description: 'Fórmula vegana con aminoácidos y colágeno para un lacio dócil, cero formol y sedosidad de 4 a 6 meses.',
    basePrice: 60,
    durationMinutes: 150
  },
  {
    id: '6',
    name: 'Lavado & Brushing Glam',
    category: 'cortes',
    categoryLabel: 'Cortes & Brushing',
    description: 'Lavado sensorial en bacha ergonómica, masaje estimulante y secado profesional con ondas o pulido lacio.',
    basePrice: 18,
    durationMinutes: 40
  },
  {
    id: '7',
    name: 'Pack Novias & Eventos VIP',
    category: 'paquetes',
    categoryLabel: 'Paquetes Especiales',
    description: 'Peinado de gala + Make-up larga duración + Sesión previa de prueba + Copa de bienvenida mimosa.',
    basePrice: 120,
    durationMinutes: 210
  },
  {
    id: '8',
    name: 'Dúo Amigas Spa Capilar',
    category: 'paquetes',
    categoryLabel: 'Paquetes Especiales',
    description: 'Sesión compartida con manicure semipermanente rusa y mascarilla reconstructiva bio-molecular.',
    basePrice: 85,
    durationMinutes: 120
  }
];

export const SALON_ADDONS: SalonAddon[] = [
  {
    id: '1',
    name: 'Ampolla Reparadora S.O.S. Bio-Cauterizante',
    description: 'Inyección de aminoácidos puros para puntas frágiles (+15 min)',
    price: 10,
    durationMinutes: 15
  },
  {
    id: '2',
    name: 'Matizador Especial Anti-Amarillo / Cenizo',
    description: 'Pigmentos micronizados para neutralizar tonos cobrizos (+20 min)',
    price: 15,
    durationMinutes: 20
  },
  {
    id: '3',
    name: 'Masaje Craneal con Aceites Esenciales de Lavanda',
    description: 'Estimulación del folículo piloso y relajación sensorial (+15 min)',
    price: 8,
    durationMinutes: 15
  }
];

export const STYLISTS: Stylist[] = [
  {
    id: 'camila',
    name: 'Camila Torres',
    role: 'Keratinas & Corte Visagista',
    chair: 'Sillón #01',
    status: 'ocupada',
    statusText: 'Ocupada • Balayage Rubio',
    timeDetail: '45m rest.',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAJY99RagzkzBojD6pDWxL2zE9G_0Z37LV_HOeRZ1kfkUEb1gjhWECC5Rjhwn-V7joj4-03qitNP9QrsX2n379Peqw50GST1XcBhC_YgILgKAk-9L51TE3i5xeapo6ueMVJhWWGDdoLqGXWpnFO6lzrcS4MXqe6ROrGxXHQgVpunvdB6nQsxnRUPFNH39agPx5cacc6H8oFUB36tsPPruvbUamNI3JwK3qnUz1HNg3HKk4vjecCC-I'
  },
  {
    id: 'mateo',
    name: 'Mateo Silva',
    role: 'Balayage & Color Master',
    chair: 'Sillón #02',
    status: 'disponible',
    statusText: 'Libre • Listo para atender',
    timeDetail: 'Disponible',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAVAdlGck-AIL2f3HN7FtLkfGCZ0CeLlSmjKYkpqPiZ0PDFShpJ7ljpB9PvRPIK8xT1JjxlH8hE3zo6G2eLCad1F5HJzBJXnXwYeED6kacDe_a3IZp2SEXcAiyQXlZXpWZiTuXOYzhffZx2fwWkHWZptMcQ2TX1IcS-_q1Z6nRBHwdg1P8eUfsgZ1iYhewqR2QigrDfvzLeA7RMJ5XdmQMiHvKB0n93p58-i1zQ4VBEdY0KQbvpSqs'
  },
  {
    id: 'sofia',
    name: 'Sofía Méndez',
    role: 'Color Touch & Tratamientos',
    chair: 'Sillón #04',
    status: 'en_pausa',
    statusText: 'Pausa de café y preparación',
    timeDetail: 'Vuelve 10:00',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAmI0CsQJ99xXRycsLn83wJodkWrADUFwTxu1aWb_Fk1zQ5mBXHlS2_08B-9agf4LBAKPZUfHRc1DOplPJUw2aHqaNkmrZwBeSlMoT-_Ar_4eycNMxYn1nTFcbVCYnd9XIdv3mUdHhzCOYElzsyxb6OiEZfa7VMXH76Botn5IeF1UyPJZWKAecGMPJOaS1T4UxRujqmiXv5RVPNz43YYHYGa3Qj7TQl5IBA-IT3sfQvlK2aE99lBlY'
  }
];

export const INITIAL_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-1',
    time: '09:30 AM',
    clientName: 'Valeria Guzmán',
    clientAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDoYI04Rho-WE_hrLTyxHl7NdthVXDfSX2eRC4Jt9r1Y5lEVIbqm-1234hSO6gnhlZojc_ECyZUV3kPk3NqhzkpCmipAIq6U1_qhtQL7eUUpg7sUHHWcQwDaE2JTR2eBzLGhqWDuRsKzaRbrjIvgS3RUacGCQJRPHd6uRjpg8UiJYIteHPixLI41-bfj8AkCFY53L5QsYNG1dvsPPEcLbTiZ45mz0znF6Ab_HdmxfHJNjksBP2JlvI',
    clientType: 'Cliente Frecuente (VIP)',
    serviceName: 'Balayage Rubio Vainilla',
    serviceDetail: 'Tonalización + Nutrición Kérastase',
    stylist: 'Camila Torres',
    status: 'en_proceso',
    total: 120.00,
    date: '2024-10-16',
    durationStr: '2h 30m'
  },
  {
    id: 'apt-2',
    time: '10:15 AM',
    clientName: 'Lucía Romero',
    clientAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCGrslbofxFaisWixd0ad3xONJuzeWlZ0pw8purm-ER1wzBtuFsGfSu-xepnDkLM0PCm50zQ6KD9eXz7hgyT_ir0IcSiO0tgEnLFF2lggRMCJH3pDacR7onnyM8SjxG6rXC9Bw_18_J3h2jD-Gzr6W9QOt8a0V_I1Q7QIURXMzrD552LuwGJ04IhSxBF-3BRrtIyH-ZaEXZBOZMJAtLobH7nq6YbvMucuhaSaWq2uV623mNofv4xkE',
    clientType: '1ª Visita',
    serviceName: 'Corte Bob Francés + Blowout',
    serviceDetail: 'Diseño de autor & texturizado',
    stylist: 'Mateo Silva',
    status: 'confirmada',
    total: 45.00,
    date: '2024-10-16',
    durationStr: '1h 15m'
  },
  {
    id: 'apt-3',
    time: '11:00 AM',
    clientName: 'Mariana Costa',
    clientType: 'Cliente Regular',
    serviceName: 'Color Touch Gloss & Raíz',
    serviceDetail: 'Neutralización de cobrizos',
    stylist: 'Sofía Méndez',
    status: 'en_espera',
    total: 95.00,
    date: '2024-10-16',
    durationStr: '1h 30m'
  },
  {
    id: 'apt-4',
    time: '12:30 PM',
    clientName: 'Beatriz Palma',
    clientAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDf6IdijuVWcrGQnt9EZA-ZWQHNjI5-eCCqwq3RRhz7MNLVAz2nmdGlikFcEgBzN2ijfroHa50gU3CNHLA3h-r11YXwG5L4r1nIR4u2w-DgiF8s82ss3XExtPQ3WjzmjfanG-oP1cnl207TULS9FYbB_B3YLQuuLUAzUmJy7OBTcl4Owe3MowHGZgibrhOUMKc171lNf4dMwK8PTPD7A9PnRlf5LjOlIaUpOUoXl9T2XpMqHh6vZSs',
    clientType: 'Membresía Bella Glam',
    serviceName: 'Alisado Progresivo Orgánico',
    serviceDetail: 'Sellado térmico de keratina',
    stylist: 'Camila Torres',
    status: 'confirmada',
    total: 140.00,
    date: '2024-10-16',
    durationStr: '2h 15m'
  },
  {
    id: 'apt-5',
    time: '14:00 PM',
    clientName: 'Elena Domínguez',
    clientType: 'Cita Online',
    serviceName: 'Ondas Glamour & Maquillaje Social',
    serviceDetail: 'Evento de gala',
    stylist: 'Mateo Silva',
    status: 'confirmada',
    total: 85.00,
    date: '2024-10-16',
    durationStr: '1h 30m'
  },
  {
    id: 'apt-6',
    time: '16:15 PM',
    clientName: 'Lucía Méndez',
    clientAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA1_dDvUsWXMk1zAB7r0tAS-oyQjR0zT4b1ehlL3utnvMehImESoV_kvRlPx0aKBnJzCwZkc1HnetJ-FN5EhtrlnMrH_Vd2hryOV683474gDXl0Aq5toSkvwxshJ3PXa__HIzpbLi3NyxrIZNukfyqlLXfK-9Tp9GDmGEhgqm3ZjtoTpFbMWjW8XJat61YhM_TNtAeaOzE7_G5Rs7EpAg_X6PCjfwf00PAjbxIObOSA7eUPLrjqEJQ',
    clientType: 'Cliente Regular',
    serviceName: 'Peinado Evento Glamour',
    serviceDetail: 'Recogido texturizado con apliques',
    stylist: 'Sofía Méndez',
    status: 'por_confirmar',
    total: 60.00,
    date: '2024-10-16',
    durationStr: '1h 00m'
  }
];

export const INITIAL_CLIENTS: ClientProfile[] = [
  {
    id: 'client-1',
    name: 'Valentina Ramos',
    tier: 'VIP Gold',
    category: 'vip',
    phone: '+54 9 11 5821-9942',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCzL6Fxjs9zu1xe-5BBi2ppTcfNSPhSi1aW0qFhSQ9gnmkFzZPAJlt_QXWLs0nNFdOMpAeuhg71fAzulSEkcMB1s-410tB75Sms9W97doJV6EjuUY1lANkYniLYtGZ8lba4hHp83xLCxdCIAicdnaNXSTDhJLQSvVem7STvDLvS_aoz_PuKltctJ-5T4qUll1MfBCJZHoqmmM9711x28DhR5SaqGoertULwMs_3tX4neYNMuJWedIE',
    points: 450,
    visitsCount: 18,
    lastService: 'Balayage Rubio Vainilla',
    lastServiceTimeAgo: 'Hace 2 sem.',
    technicalFormula: 'Fórmula Balayage: Decolorante Blondor Multi-Blonde al 6% (20 vol) con Plex protector. Enjuague con emulsión ácida. Matiz de raíz 7/1 y largos 9/60 + 10/38 con Revelador Pastel 1.9% durante 15 minutos.',
    notes: 'Tono base 6.1 + Matiz Ilumina 9/60. Cuidado Olaplex #3.'
  },
  {
    id: 'client-2',
    name: 'Camila Sotomayor',
    tier: 'Frecuente',
    category: 'frecuente',
    phone: '+54 9 11 4410-3320',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDNKwJjuZ2a0qYXCXADA4he-VHp8i_F8gaBTmnoM_2HCoS_4mTAqM87QwR6eXcAA4TxpcUvkeSVdcjJl-sQlB1KjyWpbffIK_fN03NDIUx1UD7VvkdAApRJRmadKenxrIruDrQKClf3OldunD0e97172ki5id-TBX5NCBQrFqQDvDitER6luYzu4wNm3fKMANFU7yYtahi9OCYKFl6gO_HhF7ITfKG2NtLp1GWSM_cgwKXzgFfKhOw',
    points: 180,
    visitsCount: 7,
    lastService: 'Corte Bob & Kérastase',
    lastServiceTimeAgo: 'Hace 1 mes',
    technicalFormula: 'No registra fórmulas de color activas. Historial capilar: Tratamiento Fusio-Dose Kérastase (Booster Nutritivo + Concentrado Oleo-Fusion). Prefiere despuntes cada 6 semanas.',
    notes: 'Tratamiento Fusio-Dose Nutrición Intensa. Sin tintura.'
  },
  {
    id: 'client-3',
    name: 'Paola Gómez',
    tier: 'Nueva',
    category: 'nuevo',
    phone: '+54 9 11 7309-8812',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB6OZEmfM0RPOEcVyCvfRu5_4EBBmYGJ2jaB4eLgXpPSu0SBM2dihYcDPdTX_mYaZriEytIlyHr0-smNqNe-zs-TvL82rTpEiBfa-hucnuWmoUlEbGctwYpWV8VMHRAR6FxeO36B8P79CXkdx8TIDLH0rWEYR69q-FiaA4EciYU6mDv3tUtgVaDxKcK2phx49OCz_ABPC4v72BB7p-voZylvgCxnypIeDTd6JWyibJLejWIK6sZXGk',
    points: 50,
    visitsCount: 1,
    lastService: 'Tinte Chocolate Glacé',
    lastServiceTimeAgo: 'Hace 4 días',
    technicalFormula: 'Fórmula Tinte Chocolate Glacé: Wella Color Touch 30g 5/71 + 15g 6/77 con 90ml de Emulsión Color Touch 1.9% (6 vol). Tiempo de pose: 25 min en raíz y emulsión en largos por 5 min. Lavado con champú post-color pH neutro.',
    notes: 'Color Touch 5/71 + 6/77 con emulsión al 1.9%. Raíz completa.'
  },
  {
    id: 'client-4',
    name: 'Elena Castro',
    tier: 'VIP Silver',
    category: 'vip',
    phone: '+54 9 11 6023-1194',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCc_zNdcHtBr-VgXSgKtxDapXlwZySoOZjaMsHz05Xtl_gX_ndR_EAKJJBVlN-U5w-L3xuRQfoBIBxz452RTUASo1CmNQkmTci5fDeteHzYTM7IR61LBa6PZCzG1xwmbO3aZhOSRLJ5h7r6-5stris31kxG6YSf2vlOvzBEJtdPfH_S-BwBzEVaGSk9x7NmjDzTTW-cvekS0ampEmFZViNfUsBxOajGlsB_fUkSt4nnzyZ_hghbhP4',
    points: 310,
    visitsCount: 12,
    lastService: 'Alisado Orgánico Keratina',
    lastServiceTimeAgo: 'Hace 3 sem.',
    technicalFormula: 'Fórmula & Especificación: Nano-Keratina Orgánica termoplástica enriquecida con aminoácidos de seda y aceite de argán. Tiempo de reposo: 40 min. Sellado térmico con plancha de titanio a 210°C (7 pasadas por mecha fina). No compatible con amoníaco por 3 meses.',
    notes: 'Nano-keratina sin formol. Sellado a 210°C. Cabello fino sensible.'
  }
];

export const SALON_PROMOS: SalonPromo[] = [
  {
    id: 'p-1',
    title: 'Combo Glow & Cut',
    badge: '-29%',
    description: 'Corte de puntas milimétrico + Hidratación de colágeno intensiva + Brushing pulido sedoso.',
    price: 39,
    originalPrice: 55,
    discountTag: '-29%',
    duration: '1h 15m',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCB2b5Qmqrg2i1O1mTLpSlc5GNsXB2Im7o7OVaxGafGVqbT2rPV-bQdQ0LZ1M1MH3tfiIUyNBxNZE1oUk_snX8a9mCAERBv53q5V_3h1lm9-C2iazmRmgsTI0hKkPXyVSCSNOc_b8tUrTa8WwK0fH6TFtdRM7UYcVvWgqcZ1yqNl8lf2um2MAdoq88AGds6zZY_qNpD7MnnCE5awR8V98h9WvRbzPBvzgh0S9ZEdgZyvy_ML0tDiRE',
    perks: 'Duración: 1h 15m'
  },
  {
    id: 'p-2',
    title: 'Dúo Amigas Spa',
    badge: 'Especial 2x1',
    description: '2x1 en Manicure Semipermanente Rusa o 30% de descuento en el segundo tinte completo.',
    price: 70,
    originalPrice: 100,
    discountTag: '2x1',
    duration: '2h 00m',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBVUbgDISFkq1LNcm1UCh9CBqJmU65FBudWDmVyQSTM1UWg4WJxbHK2iLn2T3kTc9Df2Db1v0ahxHix11xJIyzsEyTLhJX7udZNag1kqrZ1a6M3qJW-QFINMZUQNBfjtLWDGElbfiSnf1iMyVdGXuJezFPJ2aStPSVtqKeonaVKg11csTl93T1U42kqnNeeto5D-PHPBr286I83AxMcDUIqhiQ5jt296tu47V2jZdLe4v2eQYy6e78',
    perks: 'Válido con reserva compartida'
  },
  {
    id: 'p-3',
    title: 'Plan Novias & Eventos',
    badge: 'VIP Pack',
    description: 'Peinado de gala + Make-up larga duración + Sesión previa de prueba + Copa de bienvenida.',
    price: 120,
    discountTag: 'VIP',
    duration: '3h 30m',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAZA1UN0HMi8zUyRTmitxD4XO4rIfD4TO7Xi9swJ2YqubjqmZf8PQ_ZNzMNabvRBqm9Tys0gGjU4xO6if0Js7YSzq0vRcB1C-uAr9iWRJB0D8CDq5VwgHeCL3nBWskYoegvJIMSLeLcK93JQJkWh5IdrnygOSBylX5TFzdU1ahtZntXovornjQCzChUp1YDMP4u1UJAi205cr7SkCJ_wvIvU8N9xNiUK_MYIOy8fGEr1_FE__3Bm_s',
    perks: 'Incluye brindis y asesoría'
  }
];

export const BRAND_LOGO_URL = 'https://lh3.googleusercontent.com/aida/AEtjO1VkwR7ONM6Uhq7d1A0BqbW8HImU1m2F28Mt1ZB7snXeHYZrex12UlKu1XAvJYk86mxVIn0ROjcK2bVuv0Cpf6fYDkaOsVCmC6JgpAvXweyKE6Lty4VjM1fp0LUdzXvUyymoFDml6nJ_wPx4-NXkdux19ixcycQbKQMejP1h_4UQ9KZhiR-tVgSv63mwpti1d0qCcIxTqNEf6t5Brbr2flT_760uKXQGMWybPw-Fx67VXnBuUhqwkuj7qw';

export const ADMIN_AVATAR_URL = 'https://lh3.googleusercontent.com/aida/AEtjO1WuoCcnsMcgc4l_Cgs3Mio8SF2VDP_1N4WGcPyE9r9vg2wBECjgE3FO2DzrXdTSHkDJmwWO1qXktYr0oRFRIuHzi9OrR-FTdNpvhkNcMhwUgSJYqrWUQKJwIx6bXiykpyN5o4J8bXrHyxFYaGYWoNlAduxyGhaf6l7ybRJ_fmUDqRCJggyotdfMobTKAgQN-rcsK37pDBW63K3U2qnlMQVSRc_34tCZ9ss2_mGzbAxXnewY3nynU8XArw';

export const LUXURY_SINK_IMAGE_URL = 'https://lh3.googleusercontent.com/aida-public/AB6AXuDR28MazyqP-aRNhEJEzBJfxpf-QuESlcsE6Mrsvqwdml-OY5GfW5ihKspFHzEjwckFkx6q-wEYK0PIy9toDWhnmICNNCQed-f4gAOyBITMOieVJEwVBoL7yqOv9DGxJqGg3cd2Ng8X6wm17ukVfQbDvyWemO6QqrU0HXWx-sLqhH8URN0iOh69Qh9bSvs3qzP60ygucGqLoe6ujN0qM5M3fuDTbFgedaOk3gwrb_wWjugabwdpAsg';

export const SUGGESTED_STYLIST_AVATAR = 'https://lh3.googleusercontent.com/aida-public/AB6AXuDLTfJ-OGwZwrsOh2We2A1EJvOktaxGBx2v2jpEuREP716HLt2EnoTLRyqW860T5J2mdIOGzwanLJZ6nN0vyHrWnbTqMYYSczJzCOsUQZEEQ30gHsuYTX6rkVxVAqP302qD-kXZWAtiwPwtHDpBUuAtpWAWz0DuBBEorY2qymKZ70LXPwz20dftfzb7jF8rT5n0x12T5QaS7j7pkyN2hMMzDXfN25CW1T25GNXj-EM8-9YoqyJeydk';
